import os
import re
from typing import Dict, List, Tuple, Any
import json
import datetime
from stable_diffusion_integration import GeradorImagemStableDiffusion

class AnalisadorPromptImagem:
    """
    IA que analisa prompts de imagem e os otimiza para gerar resultados precisos
    """
    
    def __init__(self):
        self.estilos_desenho = {
            'simples': 'simple line art, clean lines, minimal details, coloring book style, black and white outline',
            'detalhado': 'detailed illustration, intricate patterns, rich textures, complex design elements',
            'educativo': 'educational illustration, clear labels, instructional diagram style, child-friendly',
            'mandala': 'mandala pattern, geometric shapes, symmetrical design, intricate patterns',
            'cartoon': 'cartoon style, friendly characters, bright colors, child-friendly animation style',
            'realista': 'realistic illustration, detailed shading, photorealistic style'
        }
        
        self.faixas_etarias = {
            '3-5 anos': 'very simple, large shapes, thick lines, minimal details, toddler-friendly',
            '6-8 anos': 'simple but engaging, moderate detail, clear shapes, elementary school level',
            '9-12 anos': 'more complex, detailed elements, intermediate complexity, pre-teen appropriate',
            'todas as idades': 'universally appealing, balanced complexity, family-friendly'
        }
        
        self.temas_educativos = {
            'animais': 'cute animals, friendly faces, natural habitat, educational animal illustration',
            'plantas': 'botanical illustration, plant parts clearly visible, nature education',
            'sistema solar': 'space illustration, planets, stars, educational astronomy',
            'profissões': 'people in professional uniforms, workplace settings, career education',
            'transportes': 'vehicles, transportation methods, clear vehicle details',
            'números': 'number illustrations, counting elements, mathematical concepts',
            'letras': 'alphabet illustration, letter recognition, phonics education',
            'formas': 'geometric shapes, pattern recognition, shape education',
            'cores': 'color education, rainbow elements, color theory illustration'
        }
    
    def analisar_prompt(self, tema: str, estilo: str = 'simples', idade: str = '6-8 anos') -> Dict[str, Any]:
        """
        Analisa o prompt e retorna informações estruturadas para geração de imagem
        """
        tema_lower = tema.lower()
        
        # Identifica categoria do tema
        categoria = self._identificar_categoria(tema_lower)
        
        # Gera prompt otimizado
        prompt_otimizado = self._gerar_prompt_otimizado(tema, estilo, idade, categoria)
        
        # Gera prompt negativo
        prompt_negativo = self._gerar_prompt_negativo(estilo, idade)
        
        return {
            'tema_original': tema,
            'categoria': categoria,
            'estilo': estilo,
            'idade': idade,
            'prompt_otimizado': prompt_otimizado,
            'prompt_negativo': prompt_negativo,
            'aspectos_tecnicos': self._definir_aspectos_tecnicos(estilo, idade)
        }
    
    def _identificar_categoria(self, tema: str) -> str:
        """Identifica a categoria do tema para otimizar o prompt"""
        for categoria, palavras_chave in {
            'animais': ['animal', 'cachorro', 'gato', 'pássaro', 'peixe', 'fazenda', 'selva', 'zoo'],
            'plantas': ['planta', 'flor', 'árvore', 'jardim', 'natureza', 'folha', 'raiz'],
            'sistema solar': ['planeta', 'sol', 'lua', 'estrela', 'espaço', 'astronauta'],
            'profissões': ['médico', 'professor', 'bombeiro', 'policial', 'engenheiro'],
            'transportes': ['carro', 'avião', 'trem', 'barco', 'bicicleta', 'ônibus'],
            'números': ['número', 'matemática', 'contar', 'quantidade'],
            'letras': ['letra', 'alfabeto', 'palavra', 'leitura'],
            'formas': ['círculo', 'quadrado', 'triângulo', 'forma', 'geometria'],
            'cores': ['cor', 'vermelho', 'azul', 'verde', 'amarelo', 'arco-íris']
        }.items():
            if any(palavra in tema for palavra in palavras_chave):
                return categoria
        return 'geral'
    
    def _gerar_prompt_otimizado(self, tema: str, estilo: str, idade: str, categoria: str) -> str:
        """Gera um prompt otimizado para a geração de imagem"""
        
        # Base do prompt
        prompt_base = f"A coloring book page featuring {tema}"
        
        # Adiciona estilo específico
        estilo_desc = self.estilos_desenho.get(estilo, self.estilos_desenho['simples'])
        
        # Adiciona adequação à idade
        idade_desc = self.faixas_etarias.get(idade, self.faixas_etarias['6-8 anos'])
        
        # Adiciona elementos específicos da categoria
        categoria_desc = self.temas_educativos.get(categoria, 'educational illustration')
        
        # Monta prompt completo
        prompt_completo = f"{prompt_base}, {estilo_desc}, {idade_desc}, {categoria_desc}, "
        prompt_completo += "high quality, clean design, suitable for printing, educational content, "
        prompt_completo += "black and white line art, no shading, clear outlines, coloring book style"
        
        return prompt_completo
    
    def _gerar_prompt_negativo(self, estilo: str, idade: str) -> str:
        """Gera prompt negativo para evitar elementos indesejados"""
        prompt_negativo = "blurry, low quality, messy lines, inappropriate content, "
        prompt_negativo += "violent imagery, scary elements, complex shading, "
        prompt_negativo += "already colored, filled areas, gradient fills, "
        prompt_negativo += "text, words, letters, numbers (unless specifically requested)"
        
        if '3-5 anos' in idade:
            prompt_negativo += ", too complex, small details, intricate patterns"
        
        return prompt_negativo
    
    def _definir_aspectos_tecnicos(self, estilo: str, idade: str) -> Dict[str, Any]:
        """Define aspectos técnicos para a geração"""
        return {
            'aspect_ratio': 'square',
            'quality': 'high',
            'style_weight': 0.8 if estilo == 'simples' else 0.6,
            'detail_level': 'low' if '3-5 anos' in idade else 'medium'
        }


class GeradorImagemInteligente:
    """
    Sistema inteligente de geração de imagens educativas usando Stable Diffusion
    """
    
    def __init__(self, api_key: str = None, provider: str = "stability"):
        self.analisador = AnalisadorPromptImagem()
        self.historico_geracoes = []
        self.gerador_sd = GeradorImagemStableDiffusion(api_key, provider)
        
        # Verifica se a API está configurada
        self.api_disponivel = api_key is not None
        
    def gerar_imagem_educativa(self, tema: str, estilo: str = 'simples', 
                              idade: str = '6-8 anos', caminho_arquivo: str = None) -> Dict[str, Any]:
        """
        Gera uma imagem educativa baseada nos parâmetros fornecidos
        """
        try:
            # Analisa o prompt
            analise = self.analisador.analisar_prompt(tema, estilo, idade)
            
            # Define caminho do arquivo se não fornecido
            if not caminho_arquivo:
                nome_arquivo = self._gerar_nome_arquivo(tema, estilo, idade)
                caminho_arquivo = f"/home/ubuntu/site_tea/static/images/generated/{nome_arquivo}"
            
            # Cria diretório se não existir
            os.makedirs(os.path.dirname(caminho_arquivo), exist_ok=True)
            
            # Gera a imagem usando Stable Diffusion
            if self.api_disponivel:
                resultado_sd = self.gerador_sd.gerar_desenho_educativo(
                    tema=tema,
                    estilo=estilo,
                    idade=idade,
                    caminho_arquivo=caminho_arquivo
                )
                
                if resultado_sd["sucesso"]:
                    resultado = {
                        'sucesso': True,
                        'caminho_arquivo': resultado_sd["caminho_arquivo"],
                        'analise': analise,
                        'metadata': {
                            'prompt_usado': resultado_sd["prompt_usado"],
                            'seed': resultado_sd["seed"],
                            'provider': resultado_sd["provider"],
                            'timestamp': resultado_sd["timestamp"]
                        }
                    }
                else:
                    # Fallback se a API falhar
                    resultado = self._gerar_fallback(analise, caminho_arquivo)
            else:
                # Fallback se não há API key
                resultado = self._gerar_fallback(analise, caminho_arquivo)
            
            self.historico_geracoes.append(resultado)
            return resultado
            
        except Exception as e:
            return {
                'sucesso': False,
                'erro': str(e),
                'caminho_arquivo': None
            }
    
    def _gerar_fallback(self, analise: Dict[str, Any], caminho_arquivo: str) -> Dict[str, Any]:
        """
        Fallback quando a API não está disponível - cria instruções detalhadas
        """
        try:
            prompt = analise['prompt_otimizado']
            
            # Cria um arquivo de texto com as instruções detalhadas
            with open(caminho_arquivo.replace('.png', '_instructions.txt'), 'w', encoding='utf-8') as f:
                f.write(f"INSTRUÇÕES PARA GERAÇÃO DE IMAGEM EDUCATIVA\n")
                f.write(f"=" * 50 + "\n\n")
                f.write(f"Tema: {analise['tema_original']}\n")
                f.write(f"Categoria: {analise['categoria']}\n")
                f.write(f"Estilo: {analise['estilo']}\n")
                f.write(f"Idade: {analise['idade']}\n\n")
                f.write(f"PROMPT OTIMIZADO PARA STABLE DIFFUSION:\n")
                f.write(f"{'-' * 40}\n")
                f.write(f"{prompt}\n\n")
                f.write(f"PROMPT NEGATIVO:\n")
                f.write(f"{'-' * 40}\n")
                f.write(f"{analise['prompt_negativo']}\n\n")
                f.write(f"CONFIGURAÇÕES TÉCNICAS:\n")
                f.write(f"{'-' * 40}\n")
                f.write(f"Dimensões: 512x768 (ou 512x512 para mandalas)\n")
                f.write(f"Steps: 30\n")
                f.write(f"CFG Scale: 7.5\n")
                f.write(f"Sampler: DPM++ 2M Karras\n\n")
                f.write(f"INSTRUÇÕES DE USO:\n")
                f.write(f"{'-' * 40}\n")
                f.write(f"1. Configure sua API key do Stable Diffusion\n")
                f.write(f"2. Use o prompt otimizado acima\n")
                f.write(f"3. Configure o prompt negativo para evitar conteúdo inadequado\n")
                f.write(f"4. Use as configurações técnicas recomendadas\n")
                f.write(f"5. Gere a imagem e salve como: {os.path.basename(caminho_arquivo)}\n\n")
                f.write(f"PROVIDERS RECOMENDADOS:\n")
                f.write(f"{'-' * 40}\n")
                f.write(f"- Stability AI (https://platform.stability.ai/)\n")
                f.write(f"- Replicate (https://replicate.com/)\n")
                f.write(f"- StableDiffusionAPI (https://stablediffusionapi.com/)\n")
                f.write(f"- GetImg.ai (https://getimg.ai/)\n\n")
                f.write(f"Timestamp: {datetime.datetime.now().isoformat()}\n")
            
            return {
                'sucesso': True,
                'caminho_arquivo': caminho_arquivo.replace('.png', '_instructions.txt'),
                'analise': analise,
                'tipo': 'instrucoes',
                'timestamp': self._obter_timestamp()
            }
            
        except Exception as e:
            print(f"Erro no fallback: {e}")
            return {
                'sucesso': False,
                'erro': str(e),
                'caminho_arquivo': None
            }
    
    def _gerar_nome_arquivo(self, tema: str, estilo: str, idade: str) -> str:
        """Gera nome único para o arquivo"""
        tema_limpo = re.sub(r'[^\w\s-]', '', tema).strip()
        tema_limpo = re.sub(r'[-\s]+', '_', tema_limpo)
        timestamp = self._obter_timestamp()
        return f"{tema_limpo}_{estilo}_{idade.replace('-', '_').replace(' ', '_')}_{timestamp}.png"
    
    def _obter_timestamp(self) -> str:
        """Obtém timestamp atual"""
        return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    def obter_historico(self) -> List[Dict[str, Any]]:
        """Retorna histórico de gerações"""
        return self.historico_geracoes
    
    def limpar_historico(self):
        """Limpa o histórico de gerações"""
        self.historico_geracoes = []
    
    def configurar_api(self, api_key: str, provider: str = "stability"):
        """Configura a API do Stable Diffusion"""
        self.gerador_sd = GeradorImagemStableDiffusion(api_key, provider)
        self.api_disponivel = True


# Função principal para compatibilidade com o código existente
def gerar_imagem_desenho(prompt, caminho_arquivo, api_key=None, provider="stability"):
    """
    Função principal para gerar desenhos - versão aperfeiçoada com Stable Diffusion
    """
    gerador = GeradorImagemInteligente(api_key, provider)
    
    # Extrai informações do prompt se possível
    tema = prompt
    estilo = 'simples'  # padrão
    idade = '6-8 anos'  # padrão
    
    # Tenta extrair estilo do prompt
    if 'detalhado' in prompt.lower():
        estilo = 'detalhado'
    elif 'mandala' in prompt.lower():
        estilo = 'mandala'
    elif 'educativo' in prompt.lower():
        estilo = 'educativo'
    
    # Tenta extrair idade do prompt
    if '3-5' in prompt or 'infantil' in prompt.lower():
        idade = '3-5 anos'
    elif '9-12' in prompt or 'fundamental' in prompt.lower():
        idade = '9-12 anos'
    
    resultado = gerador.gerar_imagem_educativa(tema, estilo, idade, caminho_arquivo)
    return resultado.get('sucesso', False)


# Classe para configuração e gerenciamento da API
class ConfiguradorStableDiffusion:
    """
    Classe para configurar e gerenciar as APIs do Stable Diffusion
    """
    
    def __init__(self):
        self.config_file = "/home/ubuntu/site_tea/config/sd_config.json"
        self.config = self._carregar_config()
    
    def _carregar_config(self) -> Dict[str, Any]:
        """Carrega configuração do arquivo"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            print(f"Erro ao carregar config: {e}")
        
        return {
            "api_key": None,
            "provider": "stability",
            "configurado": False
        }
    
    def salvar_config(self, api_key: str, provider: str = "stability"):
        """Salva configuração da API"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            
            self.config = {
                "api_key": api_key,
                "provider": provider,
                "configurado": True,
                "data_configuracao": datetime.datetime.now().isoformat()
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Erro ao salvar config: {e}")
            return False
    
    def obter_config(self) -> Dict[str, Any]:
        """Obtém configuração atual"""
        return self.config
    
    def esta_configurado(self) -> bool:
        """Verifica se a API está configurada"""
        return self.config.get("configurado", False) and self.config.get("api_key") is not None

