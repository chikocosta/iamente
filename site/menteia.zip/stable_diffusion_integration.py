import os
import requests
import json
import base64
import time
import datetime
from typing import Dict, List, Optional, Any
import hashlib
import uuid

class StableDiffusionAPI:
    """
    Integração com APIs do Stable Diffusion para geração de imagens originais
    """
    
    def __init__(self, api_key: str = None, provider: str = "stability"):
        self.api_key = api_key or os.getenv('STABLE_DIFFUSION_API_KEY')
        self.provider = provider
        self.base_urls = {
            "stability": "https://api.stability.ai/v1",
            "replicate": "https://api.replicate.com/v1",
            "stablediffusionapi": "https://stablediffusionapi.com/api/v3",
            "getimg": "https://api.getimg.ai/v1"
        }
        self.headers = self._get_headers()
        
    def _get_headers(self) -> Dict[str, str]:
        """Configura headers baseado no provedor"""
        if self.provider == "stability":
            return {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        elif self.provider == "replicate":
            return {
                "Authorization": f"Token {self.api_key}",
                "Content-Type": "application/json"
            }
        elif self.provider == "stablediffusionapi":
            return {
                "Content-Type": "application/json"
            }
        else:
            return {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
    
    def gerar_imagem_educativa(self, prompt: str, negative_prompt: str = "", 
                              width: int = 512, height: int = 512,
                              steps: int = 30, cfg_scale: float = 7.0,
                              seed: int = None) -> Dict[str, Any]:
        """
        Gera uma imagem educativa usando Stable Diffusion
        """
        try:
            # Gera seed único se não fornecido para garantir originalidade
            if seed is None:
                seed = self._generate_unique_seed(prompt)
            
            # Otimiza o prompt para conteúdo educativo
            optimized_prompt = self._optimize_educational_prompt(prompt)
            optimized_negative = self._get_educational_negative_prompt(negative_prompt)
            
            # Chama a API baseada no provedor
            if self.provider == "stability":
                return self._generate_stability_ai(optimized_prompt, optimized_negative, 
                                                 width, height, steps, cfg_scale, seed)
            elif self.provider == "replicate":
                return self._generate_replicate(optimized_prompt, optimized_negative,
                                              width, height, steps, cfg_scale, seed)
            elif self.provider == "stablediffusionapi":
                return self._generate_stablediffusionapi(optimized_prompt, optimized_negative,
                                                       width, height, steps, cfg_scale, seed)
            else:
                return {"sucesso": False, "erro": "Provedor não suportado"}
                
        except Exception as e:
            return {"sucesso": False, "erro": str(e)}
    
    def _generate_unique_seed(self, prompt: str) -> int:
        """Gera seed único baseado no prompt e timestamp para garantir originalidade"""
        timestamp = str(time.time())
        unique_string = f"{prompt}_{timestamp}_{uuid.uuid4()}"
        hash_object = hashlib.md5(unique_string.encode())
        return int(hash_object.hexdigest()[:8], 16)
    
    def _optimize_educational_prompt(self, prompt: str) -> str:
        """Otimiza o prompt para conteúdo educativo e infantil"""
        educational_keywords = [
            "educational illustration",
            "child-friendly",
            "coloring book style",
            "simple line art",
            "clean design",
            "high quality",
            "detailed but not complex",
            "suitable for children",
            "bright and cheerful",
            "safe content"
        ]
        
        # Adiciona palavras-chave educativas
        optimized = f"{prompt}, {', '.join(educational_keywords[:4])}"
        
        # Remove conteúdo potencialmente inadequado
        inappropriate_words = ["scary", "violent", "dark", "horror", "weapon"]
        for word in inappropriate_words:
            optimized = optimized.replace(word, "friendly")
        
        return optimized
    
    def _get_educational_negative_prompt(self, base_negative: str = "") -> str:
        """Gera prompt negativo para evitar conteúdo inadequado"""
        educational_negative = [
            "inappropriate content",
            "violent imagery",
            "scary elements",
            "adult content",
            "weapons",
            "blood",
            "dark themes",
            "horror",
            "nsfw",
            "low quality",
            "blurry",
            "distorted",
            "ugly",
            "bad anatomy",
            "extra limbs",
            "malformed",
            "text",
            "watermark",
            "signature"
        ]
        
        combined_negative = base_negative + ", " + ", ".join(educational_negative)
        return combined_negative.strip(", ")
    
    def _generate_stability_ai(self, prompt: str, negative_prompt: str,
                              width: int, height: int, steps: int, 
                              cfg_scale: float, seed: int) -> Dict[str, Any]:
        """Gera imagem usando Stability AI API"""
        url = f"{self.base_urls['stability']}/generation/stable-diffusion-v1-6/text-to-image"
        
        payload = {
            "text_prompts": [
                {"text": prompt, "weight": 1.0},
                {"text": negative_prompt, "weight": -1.0}
            ],
            "cfg_scale": cfg_scale,
            "height": height,
            "width": width,
            "samples": 1,
            "steps": steps,
            "seed": seed
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            if "artifacts" in data and len(data["artifacts"]) > 0:
                image_data = data["artifacts"][0]["base64"]
                return {
                    "sucesso": True,
                    "image_base64": image_data,
                    "seed": seed,
                    "prompt_usado": prompt,
                    "provider": "stability_ai"
                }
        
        return {
            "sucesso": False,
            "erro": f"Erro na API: {response.status_code} - {response.text}"
        }
    
    def _generate_replicate(self, prompt: str, negative_prompt: str,
                           width: int, height: int, steps: int,
                           cfg_scale: float, seed: int) -> Dict[str, Any]:
        """Gera imagem usando Replicate API"""
        url = f"{self.base_urls['replicate']}/predictions"
        
        payload = {
            "version": "ac732df83cea7fff18b8472768c88ad041fa750ff7682a21affe81863cbe77e4",
            "input": {
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "width": width,
                "height": height,
                "num_inference_steps": steps,
                "guidance_scale": cfg_scale,
                "seed": seed
            }
        }
        
        response = requests.post(url, headers=self.headers, json=payload)
        
        if response.status_code == 201:
            prediction = response.json()
            prediction_id = prediction["id"]
            
            # Aguarda a conclusão
            for _ in range(60):  # Máximo 60 tentativas (5 minutos)
                status_response = requests.get(
                    f"{self.base_urls['replicate']}/predictions/{prediction_id}",
                    headers=self.headers
                )
                
                if status_response.status_code == 200:
                    status_data = status_response.json()
                    if status_data["status"] == "succeeded":
                        return {
                            "sucesso": True,
                            "image_url": status_data["output"][0] if status_data["output"] else None,
                            "seed": seed,
                            "prompt_usado": prompt,
                            "provider": "replicate"
                        }
                    elif status_data["status"] == "failed":
                        return {
                            "sucesso": False,
                            "erro": f"Geração falhou: {status_data.get('error', 'Erro desconhecido')}"
                        }
                
                time.sleep(5)  # Aguarda 5 segundos antes de verificar novamente
            
            return {"sucesso": False, "erro": "Timeout na geração da imagem"}
        
        return {
            "sucesso": False,
            "erro": f"Erro na API: {response.status_code} - {response.text}"
        }
    
    def _generate_stablediffusionapi(self, prompt: str, negative_prompt: str,
                                   width: int, height: int, steps: int,
                                   cfg_scale: float, seed: int) -> Dict[str, Any]:
        """Gera imagem usando StableDiffusionAPI.com"""
        url = f"{self.base_urls['stablediffusionapi']}/text2img"
        
        payload = {
            "key": self.api_key,
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "width": str(width),
            "height": str(height),
            "samples": "1",
            "num_inference_steps": str(steps),
            "guidance_scale": cfg_scale,
            "seed": seed,
            "safety_checker": "yes",
            "enhance_prompt": "yes",
            "webhook": None,
            "track_id": None
        }
        
        response = requests.post(url, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "success" and "output" in data:
                return {
                    "sucesso": True,
                    "image_url": data["output"][0] if data["output"] else None,
                    "seed": seed,
                    "prompt_usado": prompt,
                    "provider": "stablediffusionapi"
                }
        
        return {
            "sucesso": False,
            "erro": f"Erro na API: {response.status_code} - {response.text}"
        }
    
    def salvar_imagem_base64(self, image_base64: str, caminho_arquivo: str) -> bool:
        """Salva imagem em base64 para arquivo"""
        try:
            # Remove prefixo se presente
            if image_base64.startswith('data:image'):
                image_base64 = image_base64.split(',')[1]
            
            # Decodifica e salva
            image_data = base64.b64decode(image_base64)
            
            # Cria diretório se não existir
            os.makedirs(os.path.dirname(caminho_arquivo), exist_ok=True)
            
            with open(caminho_arquivo, 'wb') as f:
                f.write(image_data)
            
            return True
        except Exception as e:
            print(f"Erro ao salvar imagem: {e}")
            return False
    
    def baixar_imagem_url(self, image_url: str, caminho_arquivo: str) -> bool:
        """Baixa imagem de URL e salva"""
        try:
            response = requests.get(image_url)
            if response.status_code == 200:
                # Cria diretório se não existir
                os.makedirs(os.path.dirname(caminho_arquivo), exist_ok=True)
                
                with open(caminho_arquivo, 'wb') as f:
                    f.write(response.content)
                
                return True
            return False
        except Exception as e:
            print(f"Erro ao baixar imagem: {e}")
            return False


class GeradorImagemStableDiffusion:
    """
    Sistema integrado de geração de imagens educativas usando Stable Diffusion
    """
    
    def __init__(self, api_key: str = None, provider: str = "stability"):
        self.api = StableDiffusionAPI(api_key, provider)
        self.historico_geracoes = []
    
    def gerar_desenho_educativo(self, tema: str, estilo: str = "simples",
                               idade: str = "6-8 anos", caminho_arquivo: str = None) -> Dict[str, Any]:
        """
        Gera um desenho educativo usando Stable Diffusion
        """
        try:
            # Constrói prompt otimizado
            prompt = self._construir_prompt_educativo(tema, estilo, idade)
            negative_prompt = self._construir_negative_prompt(estilo, idade)
            
            # Define dimensões baseadas no estilo
            width, height = self._get_dimensions(estilo)
            
            # Define caminho do arquivo se não fornecido
            if not caminho_arquivo:
                nome_arquivo = self._gerar_nome_arquivo(tema, estilo, idade)
                caminho_arquivo = f"/home/ubuntu/site_tea/static/images/generated/{nome_arquivo}"
            
            # Gera a imagem
            resultado = self.api.gerar_imagem_educativa(
                prompt=prompt,
                negative_prompt=negative_prompt,
                width=width,
                height=height,
                steps=30,
                cfg_scale=7.5
            )
            
            if resultado["sucesso"]:
                # Salva a imagem
                sucesso_salvamento = False
                if "image_base64" in resultado:
                    sucesso_salvamento = self.api.salvar_imagem_base64(
                        resultado["image_base64"], caminho_arquivo
                    )
                elif "image_url" in resultado:
                    sucesso_salvamento = self.api.baixar_imagem_url(
                        resultado["image_url"], caminho_arquivo
                    )
                
                if sucesso_salvamento:
                    resultado_final = {
                        "sucesso": True,
                        "caminho_arquivo": caminho_arquivo,
                        "prompt_usado": resultado["prompt_usado"],
                        "seed": resultado["seed"],
                        "provider": resultado["provider"],
                        "tema": tema,
                        "estilo": estilo,
                        "idade": idade,
                        "timestamp": datetime.datetime.now().isoformat()
                    }
                    
                    self.historico_geracoes.append(resultado_final)
                    return resultado_final
                else:
                    return {"sucesso": False, "erro": "Falha ao salvar a imagem"}
            else:
                return resultado
                
        except Exception as e:
            return {"sucesso": False, "erro": str(e)}
    
    def _construir_prompt_educativo(self, tema: str, estilo: str, idade: str) -> str:
        """Constrói prompt otimizado para conteúdo educativo"""
        base_prompt = f"A coloring book page featuring {tema}"
        
        # Adiciona estilo específico
        if estilo == "simples":
            style_desc = "simple line art, clean lines, minimal details, black and white outline"
        elif estilo == "detalhado":
            style_desc = "detailed illustration, intricate patterns, rich textures"
        elif estilo == "educativo":
            style_desc = "educational illustration, clear labels, instructional style"
        elif estilo == "mandala":
            style_desc = "mandala pattern, geometric shapes, symmetrical design"
        else:
            style_desc = "simple line art, clean lines"
        
        # Adiciona adequação à idade
        if "3-5" in idade:
            age_desc = "very simple, large shapes, thick lines, toddler-friendly"
        elif "6-8" in idade:
            age_desc = "simple but engaging, moderate detail, elementary school level"
        elif "9-12" in idade:
            age_desc = "more complex, detailed elements, pre-teen appropriate"
        else:
            age_desc = "universally appealing, balanced complexity"
        
        # Monta prompt completo
        prompt_completo = f"{base_prompt}, {style_desc}, {age_desc}, "
        prompt_completo += "high quality, clean design, suitable for printing, "
        prompt_completo += "educational content, child-friendly, safe for children, "
        prompt_completo += "coloring book style, black and white line art"
        
        return prompt_completo
    
    def _construir_negative_prompt(self, estilo: str, idade: str) -> str:
        """Constrói prompt negativo para evitar conteúdo inadequado"""
        negative_elements = [
            "inappropriate content", "violent imagery", "scary elements",
            "adult content", "weapons", "blood", "dark themes", "horror",
            "nsfw", "low quality", "blurry", "distorted", "ugly",
            "bad anatomy", "extra limbs", "malformed", "text", "watermark",
            "signature", "already colored", "filled areas", "gradient fills"
        ]
        
        if "3-5" in idade:
            negative_elements.extend(["too complex", "small details", "intricate patterns"])
        
        return ", ".join(negative_elements)
    
    def _get_dimensions(self, estilo: str) -> tuple:
        """Define dimensões baseadas no estilo"""
        if estilo == "mandala":
            return (512, 512)  # Quadrado para mandalas
        else:
            return (512, 768)  # Retrato para a maioria dos desenhos
    
    def _gerar_nome_arquivo(self, tema: str, estilo: str, idade: str) -> str:
        """Gera nome único para o arquivo"""
        import re
        tema_limpo = re.sub(r'[^\w\s-]', '', tema).strip()
        tema_limpo = re.sub(r'[-\s]+', '_', tema_limpo)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{tema_limpo}_{estilo}_{idade.replace('-', '_').replace(' ', '_')}_{timestamp}.png"
    
    def obter_historico(self) -> List[Dict[str, Any]]:
        """Retorna histórico de gerações"""
        return self.historico_geracoes


# Função para compatibilidade com o código existente
def gerar_imagem_desenho_sd(prompt: str, caminho_arquivo: str, 
                           api_key: str = None, provider: str = "stability") -> bool:
    """
    Função principal para gerar desenhos usando Stable Diffusion
    """
    try:
        gerador = GeradorImagemStableDiffusion(api_key, provider)
        resultado = gerador.gerar_desenho_educativo(prompt, caminho_arquivo=caminho_arquivo)
        return resultado.get("sucesso", False)
    except Exception as e:
        print(f"Erro na geração: {e}")
        return False

