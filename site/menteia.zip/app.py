from flask import Flask, render_template, request, send_file, jsonify, redirect, url_for
import os
import json
from datetime import datetime
from fpdf import FPDF
import sys

# Adiciona o diretório atual ao path para importar módulos locais
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importa o sistema de IA integrado
try:
    from sistema_ia_integrado import processar_pedido_educativo, obter_relatorio_sistema, exportar_conteudo_gerado
    from media_generate_image import gerar_imagem_desenho
    IA_DISPONIVEL = True
except ImportError as e:
    print(f"Aviso: Sistema de IA não disponível: {e}")
    IA_DISPONIVEL = False

app = Flask(__name__)

# Configurações
app.config['SECRET_KEY'] = 'sua_chave_secreta_aqui'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max

# Cria diretórios necessários
os.makedirs('static/images', exist_ok=True)
os.makedirs('static/uploads', exist_ok=True)
os.makedirs('data', exist_ok=True)

@app.route("/")
def index():
    """Página inicial"""
    return render_template("index.html")

@app.route("/gerar")
def gerar():
    """Página de geração de atividades"""
    return render_template("gerar.html")

@app.route("/gerar_atividade")
def gerar_atividade():
    """Página de geração de atividades específicas"""
    return render_template("gerar_atividade.html")

@app.route("/gerar_desenho")
def gerar_desenho():
    """Página de geração de desenhos"""
    return render_template("gerar_desenho.html")

@app.route("/gerar_jogo")
def gerar_jogo():
    """Página de geração de jogos"""
    return render_template("gerar_jogo.html")

@app.route("/gerar_livre")
def gerar_livre():
    """Página de geração livre"""
    return render_template("gerar_livre.html")

@app.route("/gerar_instrucoes")
def gerar_instrucoes():
    """Página de geração de instruções"""
    return render_template("gerar_instrucoes.html")

@app.route("/gerar_adaptada")
def gerar_adaptada():
    """Página de geração adaptada para TEA"""
    return render_template("gerar_adaptada.html")

@app.route("/gerar_tea_avancado")
def gerar_tea_avancado():
    """Página de geração avançada para TEA"""
    return render_template("gerar_tea_avancado.html")

@app.route("/historico")
def historico():
    """Página de histórico"""
    return render_template("historico.html")

@app.route("/painel")
def painel():
    """Painel administrativo"""
    return render_template("painel.html")

@app.route("/sobre")
def sobre():
    """Página sobre"""
    return render_template("sobre.html")

# APIs para geração de conteúdo

@app.route("/api/gerar_conteudo", methods=["POST"])
def api_gerar_conteudo():
    """API para gerar conteúdo educativo inteligente"""
    try:
        if not IA_DISPONIVEL:
            return jsonify({
                'sucesso': False,
                'erro': 'Sistema de IA não disponível'
            }), 500
        
        dados = request.get_json()
        if not dados:
            dados = request.form.to_dict()
        
        pedido = dados.get('pedido', '')
        incluir_imagem = dados.get('incluir_imagem', True)
        
        if not pedido:
            return jsonify({
                'sucesso': False,
                'erro': 'Pedido não fornecido'
            }), 400
        
        # Processa o pedido com o sistema de IA
        resultado = processar_pedido_educativo(pedido, incluir_imagem)
        
        return jsonify(resultado)
        
    except Exception as e:
        return jsonify({
            'sucesso': False,
            'erro': f'Erro interno: {str(e)}'
        }), 500

@app.route("/api/gerar_desenho", methods=["POST"])
def api_gerar_desenho():
    """API específica para gerar desenhos para colorir"""
    try:
        dados = request.get_json()
        if not dados:
            dados = request.form.to_dict()
        
        tema = dados.get('tema', '')
        estilo = dados.get('estilo', 'simples')
        idade = dados.get('idade_desenho', '6-8 anos')
        
        if not tema:
            return jsonify({
                'sucesso': False,
                'erro': 'Tema não fornecido'
            }), 400
        
        # Constrói prompt específico para desenho
        prompt = f"Desenho para colorir sobre {tema}, estilo {estilo}, para idade {idade}"
        
        if IA_DISPONIVEL:
            resultado = processar_pedido_educativo(prompt, incluir_imagem=True)
            return jsonify(resultado)
        else:
            # Fallback para sistema básico
            caminho_arquivo = f"static/images/desenho_{tema.replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            sucesso = gerar_imagem_desenho(prompt, caminho_arquivo)
            
            return jsonify({
                'sucesso': sucesso,
                'caminho_arquivo': caminho_arquivo if sucesso else None,
                'prompt_usado': prompt
            })
        
    except Exception as e:
        return jsonify({
            'sucesso': False,
            'erro': f'Erro interno: {str(e)}'
        }), 500

@app.route("/api/gerar_jogo", methods=["POST"])
def api_gerar_jogo():
    """API para gerar jogos educativos"""
    try:
        dados = request.get_json()
        if not dados:
            dados = request.form.to_dict()
        
        tema = dados.get('tema', '')
        tipo_jogo = dados.get('tipo_jogo', 'Quiz')
        idade = dados.get('idade', '6-8 anos')
        participantes = dados.get('participantes', '1-4 jogadores')
        
        if not tema:
            return jsonify({
                'sucesso': False,
                'erro': 'Tema não fornecido'
            }), 400
        
        # Constrói prompt específico para jogo
        prompt = f"Jogo educativo tipo {tipo_jogo} sobre {tema} para {idade} com {participantes}"
        
        if IA_DISPONIVEL:
            resultado = processar_pedido_educativo(prompt, incluir_imagem=False)
            return jsonify(resultado)
        else:
            # Fallback para sistema básico
            from geradores_especiais import gerar_jogo_educativo
            conteudo = gerar_jogo_educativo(tema, tipo_jogo, idade, participantes)
            
            return jsonify({
                'sucesso': True,
                'conteudo_texto': {
                    'conteudo_gerado': conteudo,
                    'template_usado': f'Jogo {tipo_jogo}',
                    'qualidade_estimada': {'nivel': 'Bom', 'score_geral': 0.7}
                }
            })
        
    except Exception as e:
        return jsonify({
            'sucesso': False,
            'erro': f'Erro interno: {str(e)}'
        }), 500

@app.route("/api/gerar_atividade_tea", methods=["POST"])
def api_gerar_atividade_tea():
    """API específica para gerar atividades adaptadas para TEA"""
    try:
        dados = request.get_json()
        if not dados:
            dados = request.form.to_dict()
        
        tema = dados.get('tema', '')
        nivel = dados.get('nivel', 'básico')
        interesse = dados.get('interesse', '')
        sensibilidade = dados.get('sensibilidade', '')
        
        if not tema:
            return jsonify({
                'sucesso': False,
                'erro': 'Tema não fornecido'
            }), 400
        
        # Constrói prompt específico para TEA
        prompt = f"Atividade para criança com TEA sobre {tema}, nível {nivel}"
        if interesse:
            prompt += f", considerando interesse em {interesse}"
        if sensibilidade:
            prompt += f", com cuidados para {sensibilidade}"
        
        if IA_DISPONIVEL:
            resultado = processar_pedido_educativo(prompt, incluir_imagem=True)
            return jsonify(resultado)
        else:
            return jsonify({
                'sucesso': False,
                'erro': 'Sistema de IA para TEA não disponível'
            }), 500
        
    except Exception as e:
        return jsonify({
            'sucesso': False,
            'erro': f'Erro interno: {str(e)}'
        }), 500

@app.route("/api/relatorio_sistema")
def api_relatorio_sistema():
    """API para obter relatório do sistema"""
    try:
        if not IA_DISPONIVEL:
            return jsonify({
                'erro': 'Sistema de IA não disponível'
            }), 500
        
        relatorio = obter_relatorio_sistema()
        return jsonify(relatorio)
        
    except Exception as e:
        return jsonify({
            'erro': f'Erro interno: {str(e)}'
        }), 500

@app.route("/api/exportar_conteudo/<id_geracao>")
def api_exportar_conteudo(id_geracao):
    """API para exportar conteúdo gerado"""
    try:
        if not IA_DISPONIVEL:
            return jsonify({
                'erro': 'Sistema de IA não disponível'
            }), 500
        
        formato = request.args.get('formato', 'markdown')
        conteudo = exportar_conteudo_gerado(id_geracao, formato)
        
        if conteudo == "Geração não encontrada":
            return jsonify({
                'erro': 'Conteúdo não encontrado'
            }), 404
        
        return jsonify({
            'conteudo': conteudo,
            'formato': formato
        })
        
    except Exception as e:
        return jsonify({
            'erro': f'Erro interno: {str(e)}'
        }), 500

# Rota original mantida para compatibilidade
@app.route("/gerar_original", methods=["POST"])
def gerar_original():
    """Rota original de geração (mantida para compatibilidade)"""
    try:
        nome = request.form.get("nome", "Criança")
        preferencia = request.form.get("preferencia", "atividades gerais")
        quantidade = int(request.form.get("quantidade", 1))

        # Usa o novo sistema se disponível
        if IA_DISPONIVEL:
            pedido = f"Criar {quantidade} atividades para {nome} que gosta de {preferencia}"
            resultado = processar_pedido_educativo(pedido, incluir_imagem=False)
            
            if resultado['sucesso']:
                conteudo = resultado['conteudo_texto']['conteudo_gerado']
                
                # Gera PDF
                pdf = FPDF()
                pdf.add_page()
                pdf.set_font("Arial", size=12)
                pdf.cell(200, 10, txt=f"Atividades para {nome}", ln=True, align='C')
                
                # Adiciona conteúdo (tratamento básico para caracteres especiais)
                try:
                    pdf.multi_cell(0, 10, txt=conteudo.encode('latin-1', 'replace').decode('latin-1'))
                except:
                    pdf.multi_cell(0, 10, txt="Conteúdo gerado com sucesso (caracteres especiais removidos)")
                
                output_path = f"data/atividades_{nome}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                pdf.output(output_path)
                
                return send_file(output_path, as_attachment=True)
            else:
                return f"Erro na geração: {resultado.get('erro', 'Erro desconhecido')}", 500
        else:
            return "Sistema de IA não disponível", 500
            
    except Exception as e:
        return f"Erro interno: {str(e)}", 500

@app.errorhandler(404)
def not_found(error):
    """Página de erro 404"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Página de erro 500"""
    return render_template('500.html'), 500

if __name__ == "__main__":
    print("🚀 Iniciando AtivaMente - Sistema de IA Educativa")
    print(f"📊 Sistema de IA: {'✅ Disponível' if IA_DISPONIVEL else '❌ Não disponível'}")
    print("🌐 Acesse: http://localhost:5000")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

