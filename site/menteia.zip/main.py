from app import app

# This file is used by the deployment service to run the Flask app.
# The 'app' object is imported from app.py.
# No app.run() call is needed here as the deployment service handles it.


