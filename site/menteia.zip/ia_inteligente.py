# 🧠 Sistema de IA Inteligente Aperfeiçoado para Geração de Conteúdo

import re
import json
import datetime
from typing import Dict, List, Tuple, Any, Optional
import random

class AnalisadorPedidosAvancado:
    """
    IA avançada que analisa pedidos dos usuários com maior precisão e inteligência
    """
    
    def __init__(self):
        self.disciplinas = {
            'matematica': {
                'palavras_chave': ['matemática', 'math', 'números', 'contas', 'soma', 'subtração', 'multiplicação', 'divisão', 'tabuada', 'frações', 'geometria', 'álgebra', 'cálculo', 'estatística', 'problemas matemáticos'],
                'peso': 1.0,
                'contextos': ['resolver', 'calcular', 'contar', 'medir', 'operações']
            },
            'ciencias': {
                'palavras_chave': ['ciências', 'ciencia', 'biologia', 'física', 'química', 'plantas', 'animais', 'corpo humano', 'sistema solar', 'planetas', 'experimentos', 'natureza', 'meio ambiente', 'laboratório'],
                'peso': 1.0,
                'contextos': ['observar', 'experimentar', 'descobrir', 'investigar', 'pesquisar']
            },
            'portugues': {
                'palavras_chave': ['português', 'linguagem', 'gramática', 'ortografia', 'redação', 'texto', 'leitura', 'escrita', 'verbos', 'substantivos', 'adjetivos', 'literatura', 'interpretação'],
                'peso': 1.0,
                'contextos': ['ler', 'escrever', 'interpretar', 'comunicar', 'expressar']
            },
            'historia': {
                'palavras_chave': ['história', 'histórico', 'passado', 'civilizações', 'brasil', 'mundo', 'guerra', 'descobrimento', 'independência', 'república', 'cultura'],
                'peso': 1.0,
                'contextos': ['aconteceu', 'época', 'período', 'antigo', 'tradicional']
            },
            'geografia': {
                'palavras_chave': ['geografia', 'países', 'continentes', 'mapas', 'relevo', 'clima', 'população', 'cidades', 'estados', 'capitais', 'localização'],
                'peso': 1.0,
                'contextos': ['localizar', 'situar', 'região', 'território', 'lugar']
            },
            'ingles': {
                'palavras_chave': ['inglês', 'english', 'vocabulário inglês', 'verbos inglês', 'cores inglês', 'números inglês', 'idioma', 'língua estrangeira'],
                'peso': 1.0,
                'contextos': ['traduzir', 'pronunciar', 'falar', 'comunicar em inglês']
            },
            'artes': {
                'palavras_chave': ['artes', 'desenho', 'pintura', 'música', 'teatro', 'dança', 'cultura', 'criatividade', 'expressão artística'],
                'peso': 1.0,
                'contextos': ['criar', 'expressar', 'desenhar', 'pintar', 'cantar']
            },
            'educacao_fisica': {
                'palavras_chave': ['educação física', 'esportes', 'jogos', 'movimento', 'coordenação', 'atividade física', 'exercícios'],
                'peso': 1.0,
                'contextos': ['mover', 'correr', 'pular', 'exercitar', 'brincar']
            },
            'tecnologia': {
                'palavras_chave': ['tecnologia', 'computador', 'programação', 'algoritmos', 'robótica', 'internet', 'digital', 'coding'],
                'peso': 1.0,
                'contextos': ['programar', 'codificar', 'desenvolver', 'criar tecnologia']
            }
        }
        
        self.faixas_etarias = {
            'infantil': {
                'indicadores': ['3 anos', '4 anos', '5 anos', '6 anos', 'educação infantil', 'pré-escola', 'pequenos', 'bebês'],
                'caracteristicas': {
                    'linguagem': 'muito simples',
                    'complexidade': 'baixa',
                    'elementos_visuais': 'muitos',
                    'tempo_atencao': 'curto'
                }
            },
            'fundamental1': {
                'indicadores': ['7 anos', '8 anos', '9 anos', '10 anos', '1º ano', '2º ano', '3º ano', '4º ano', '5º ano', 'ensino fundamental I'],
                'caracteristicas': {
                    'linguagem': 'simples e clara',
                    'complexidade': 'média-baixa',
                    'elementos_visuais': 'equilibrados',
                    'tempo_atencao': 'médio'
                }
            },
            'fundamental2': {
                'indicadores': ['11 anos', '12 anos', '13 anos', '14 anos', '6º ano', '7º ano', '8º ano', '9º ano', 'ensino fundamental II'],
                'caracteristicas': {
                    'linguagem': 'intermediária',
                    'complexidade': 'média',
                    'elementos_visuais': 'moderados',
                    'tempo_atencao': 'bom'
                }
            },
            'medio': {
                'indicadores': ['15 anos', '16 anos', '17 anos', '18 anos', 'ensino médio', '1ª série', '2ª série', '3ª série', 'adolescentes'],
                'caracteristicas': {
                    'linguagem': 'complexa',
                    'complexidade': 'alta',
                    'elementos_visuais': 'poucos',
                    'tempo_atencao': 'longo'
                }
            }
        }
        
        self.tipos_atividade = {
            'exercicios': {
                'palavras_chave': ['exercícios', 'atividades', 'questões', 'problemas', 'lista', 'praticar', 'treinar'],
                'formato': 'estruturado',
                'objetivo': 'fixação de conteúdo'
            },
            'jogos': {
                'palavras_chave': ['jogo', 'brincadeira', 'diversão', 'lúdico', 'quiz', 'competição', 'desafio'],
                'formato': 'interativo',
                'objetivo': 'engajamento e aprendizado'
            },
            'experimentos': {
                'palavras_chave': ['experimento', 'prática', 'laboratório', 'teste', 'investigação', 'descoberta'],
                'formato': 'hands-on',
                'objetivo': 'aprendizado por descoberta'
            },
            'projetos': {
                'palavras_chave': ['projeto', 'pesquisa', 'trabalho', 'investigação', 'estudo', 'desenvolvimento'],
                'formato': 'longo prazo',
                'objetivo': 'aprofundamento'
            },
            'arte': {
                'palavras_chave': ['desenho', 'colorir', 'pintar', 'criar', 'ilustração', 'expressão', 'criativo'],
                'formato': 'criativo',
                'objetivo': 'expressão e criatividade'
            }
        }
        
        # Contextos especiais para TEA (Transtorno do Espectro Autista)
        self.contextos_tea = {
            'indicadores': ['tea', 'autismo', 'autista', 'espectro autista', 'necessidades especiais'],
            'adaptacoes': {
                'estrutura': 'muito clara e previsível',
                'instrucoes': 'passo a passo detalhado',
                'elementos_visuais': 'abundantes',
                'rotina': 'estabelecida',
                'sensorial': 'considerações sensoriais'
            }
        }
    
    def analisar_pedido_avancado(self, texto: str) -> Dict[str, Any]:
        """
        Análise avançada do pedido do usuário com maior precisão
        """
        texto_original = texto
        texto_lower = texto.lower()
        
        # Análise básica
        disciplina = self._identificar_disciplina_avancada(texto_lower)
        faixa_etaria = self._identificar_faixa_etaria_avancada(texto_lower)
        tipo_atividade = self._identificar_tipo_atividade_avancada(texto_lower)
        
        # Análises específicas
        contexto_tea = self._verificar_contexto_tea(texto_lower)
        intencao_usuario = self._extrair_intencao(texto_lower)
        tema_principal = self._extrair_tema_principal_avancado(texto)
        palavras_chave = self._extrair_palavras_chave_avancadas(texto_lower)
        
        # Análise de sentimento e urgência
        sentimento = self._analisar_sentimento(texto_lower)
        nivel_urgencia = self._detectar_urgencia(texto_lower)
        
        # Score de confiança aprimorado
        score_confianca = self._calcular_score_confianca_avancado(
            disciplina, faixa_etaria, tipo_atividade, contexto_tea, intencao_usuario
        )
        
        # Recomendações inteligentes
        recomendacoes = self._gerar_recomendacoes_inteligentes(
            disciplina, faixa_etaria, tipo_atividade, contexto_tea, tema_principal
        )
        
        return {
            'texto_original': texto_original,
            'disciplina': disciplina,
            'faixa_etaria': faixa_etaria,
            'tipo_atividade': tipo_atividade,
            'tema_principal': tema_principal,
            'palavras_chave': palavras_chave,
            'contexto_tea': contexto_tea,
            'intencao_usuario': intencao_usuario,
            'sentimento': sentimento,
            'nivel_urgencia': nivel_urgencia,
            'score_confianca': score_confianca,
            'recomendacoes': recomendacoes,
            'timestamp': datetime.datetime.now().isoformat()
        }
    
    def _identificar_disciplina_avancada(self, texto: str) -> Dict[str, Any]:
        """Identificação avançada de disciplina com scores e contexto"""
        scores = {}
        contextos_encontrados = {}
        
        for disciplina, info in self.disciplinas.items():
            score = 0
            contextos = []
            
            # Pontuação por palavras-chave
            for palavra in info['palavras_chave']:
                if palavra in texto:
                    score += info['peso']
            
            # Pontuação por contextos
            for contexto in info['contextos']:
                if contexto in texto:
                    score += 0.5
                    contextos.append(contexto)
            
            scores[disciplina] = score
            contextos_encontrados[disciplina] = contextos
        
        disciplina_principal = max(scores, key=scores.get) if max(scores.values()) > 0 else 'geral'
        
        return {
            'principal': disciplina_principal,
            'scores': scores,
            'contextos': contextos_encontrados.get(disciplina_principal, []),
            'confianca': scores.get(disciplina_principal, 0) / max(scores.values()) if max(scores.values()) > 0 else 0
        }
    
    def _identificar_faixa_etaria_avancada(self, texto: str) -> Dict[str, Any]:
        """Identificação avançada de faixa etária"""
        for faixa, info in self.faixas_etarias.items():
            for indicador in info['indicadores']:
                if indicador in texto:
                    return {
                        'faixa': faixa,
                        'indicador_encontrado': indicador,
                        'caracteristicas': info['caracteristicas'],
                        'confianca': 0.9
                    }
        
        # Análise por contexto se não encontrar indicador direto
        if any(palavra in texto for palavra in ['simples', 'fácil', 'básico']):
            return {
                'faixa': 'fundamental1',
                'indicador_encontrado': 'contexto_simplicidade',
                'caracteristicas': self.faixas_etarias['fundamental1']['caracteristicas'],
                'confianca': 0.6
            }
        
        return {
            'faixa': 'fundamental1',  # padrão
            'indicador_encontrado': 'padrão',
            'caracteristicas': self.faixas_etarias['fundamental1']['caracteristicas'],
            'confianca': 0.3
        }
    
    def _identificar_tipo_atividade_avancada(self, texto: str) -> Dict[str, Any]:
        """Identificação avançada do tipo de atividade"""
        scores = {}
        
        for tipo, info in self.tipos_atividade.items():
            score = 0
            for palavra in info['palavras_chave']:
                if palavra in texto:
                    score += 1
            scores[tipo] = score
        
        tipo_principal = max(scores, key=scores.get) if max(scores.values()) > 0 else 'exercicios'
        
        return {
            'tipo': tipo_principal,
            'scores': scores,
            'formato': self.tipos_atividade[tipo_principal]['formato'],
            'objetivo': self.tipos_atividade[tipo_principal]['objetivo'],
            'confianca': scores.get(tipo_principal, 0) / max(scores.values()) if max(scores.values()) > 0 else 0.3
        }
    
    def _verificar_contexto_tea(self, texto: str) -> Dict[str, Any]:
        """Verifica se o contexto é para TEA"""
        for indicador in self.contextos_tea['indicadores']:
            if indicador in texto:
                return {
                    'presente': True,
                    'indicador': indicador,
                    'adaptacoes': self.contextos_tea['adaptacoes']
                }
        
        return {'presente': False}
    
    def _extrair_intencao(self, texto: str) -> str:
        """Extrai a intenção principal do usuário"""
        intencoes = {
            'criar': ['criar', 'gerar', 'fazer', 'produzir', 'desenvolver'],
            'ensinar': ['ensinar', 'explicar', 'mostrar', 'demonstrar', 'educar'],
            'praticar': ['praticar', 'treinar', 'exercitar', 'repetir', 'fixar'],
            'avaliar': ['avaliar', 'testar', 'verificar', 'medir', 'examinar'],
            'divertir': ['divertir', 'entreter', 'brincar', 'jogar', 'alegrar']
        }
        
        for intencao, palavras in intencoes.items():
            if any(palavra in texto for palavra in palavras):
                return intencao
        
        return 'criar'  # padrão
    
    def _extrair_tema_principal_avancado(self, texto: str) -> Dict[str, Any]:
        """Extração avançada do tema principal"""
        # Remove palavras comuns
        palavras_comuns = {
            'para', 'crianças', 'de', 'anos', 'sobre', 'atividade', 'exercício',
            'com', 'tea', 'autismo', 'ensino', 'fundamental', 'médio', 'infantil',
            'criar', 'gerar', 'fazer', 'um', 'uma', 'o', 'a', 'do', 'da', 'dos', 'das'
        }
        
        palavras = texto.split()
        tema_palavras = []
        
        for palavra in palavras:
            palavra_limpa = re.sub(r'[^\w]', '', palavra.lower())
            if palavra_limpa not in palavras_comuns and len(palavra_limpa) > 2:
                tema_palavras.append(palavra)
        
        tema_principal = ' '.join(tema_palavras[:4])  # Primeiras 4 palavras relevantes
        
        # Identifica subtemas
        subtemas = self._identificar_subtemas(texto.lower())
        
        return {
            'tema': tema_principal,
            'subtemas': subtemas,
            'palavras_relevantes': tema_palavras[:10]
        }
    
    def _identificar_subtemas(self, texto: str) -> List[str]:
        """Identifica subtemas no texto"""
        subtemas_conhecidos = {
            'animais': ['cachorro', 'gato', 'pássaro', 'peixe', 'fazenda', 'selva'],
            'plantas': ['flor', 'árvore', 'jardim', 'folha', 'raiz', 'caule'],
            'números': ['contar', 'somar', 'subtrair', 'multiplicar', 'dividir'],
            'cores': ['vermelho', 'azul', 'verde', 'amarelo', 'roxo', 'laranja'],
            'formas': ['círculo', 'quadrado', 'triângulo', 'retângulo'],
            'família': ['pai', 'mãe', 'irmão', 'irmã', 'avô', 'avó'],
            'casa': ['quarto', 'sala', 'cozinha', 'banheiro', 'jardim'],
            'escola': ['professor', 'aluno', 'sala de aula', 'recreio', 'lição']
        }
        
        subtemas_encontrados = []
        for subtema, palavras in subtemas_conhecidos.items():
            if any(palavra in texto for palavra in palavras):
                subtemas_encontrados.append(subtema)
        
        return subtemas_encontrados
    
    def _extrair_palavras_chave_avancadas(self, texto: str) -> List[Dict[str, Any]]:
        """Extração avançada de palavras-chave com relevância"""
        texto_limpo = re.sub(r'[^\w\s]', '', texto)
        palavras = texto_limpo.split()
        
        palavras_relevantes = []
        for palavra in palavras:
            if len(palavra) > 3:
                relevancia = self._calcular_relevancia_palavra(palavra, texto)
                palavras_relevantes.append({
                    'palavra': palavra,
                    'relevancia': relevancia
                })
        
        # Ordena por relevância
        palavras_relevantes.sort(key=lambda x: x['relevancia'], reverse=True)
        
        return palavras_relevantes[:8]  # Top 8 palavras-chave
    
    def _calcular_relevancia_palavra(self, palavra: str, texto: str) -> float:
        """Calcula a relevância de uma palavra no contexto"""
        # Frequência da palavra
        freq = texto.count(palavra) / len(texto.split())
        
        # Posição no texto (palavras no início são mais relevantes)
        posicao = texto.find(palavra) / len(texto)
        peso_posicao = 1 - posicao
        
        # Tamanho da palavra (palavras maiores tendem a ser mais específicas)
        peso_tamanho = min(len(palavra) / 10, 1)
        
        return freq + peso_posicao * 0.3 + peso_tamanho * 0.2
    
    def _analisar_sentimento(self, texto: str) -> str:
        """Análise básica de sentimento"""
        palavras_positivas = ['gostaria', 'adoraria', 'quero', 'preciso', 'ajuda', 'por favor']
        palavras_urgentes = ['urgente', 'rápido', 'agora', 'hoje', 'imediatamente']
        palavras_neutras = ['criar', 'gerar', 'fazer', 'desenvolver']
        
        if any(palavra in texto for palavra in palavras_urgentes):
            return 'urgente'
        elif any(palavra in texto for palavra in palavras_positivas):
            return 'positivo'
        elif any(palavra in texto for palavra in palavras_neutras):
            return 'neutro'
        else:
            return 'neutro'
    
    def _detectar_urgencia(self, texto: str) -> str:
        """Detecta nível de urgência"""
        indicadores_alta = ['urgente', 'rápido', 'agora', 'hoje', 'imediatamente', 'preciso já']
        indicadores_media = ['em breve', 'logo', 'quando possível', 'preciso']
        
        if any(indicador in texto for indicador in indicadores_alta):
            return 'alta'
        elif any(indicador in texto for indicador in indicadores_media):
            return 'média'
        else:
            return 'baixa'
    
    def _calcular_score_confianca_avancado(self, disciplina: Dict, faixa_etaria: Dict, 
                                         tipo_atividade: Dict, contexto_tea: Dict, 
                                         intencao: str) -> float:
        """Cálculo avançado do score de confiança"""
        score = 0.0
        
        # Confiança da disciplina
        score += disciplina['confianca'] * 0.3
        
        # Confiança da faixa etária
        score += faixa_etaria['confianca'] * 0.25
        
        # Confiança do tipo de atividade
        score += tipo_atividade['confianca'] * 0.25
        
        # Bonus para contexto TEA identificado
        if contexto_tea['presente']:
            score += 0.1
        
        # Bonus para intenção clara
        if intencao != 'criar':
            score += 0.1
        
        return min(score, 1.0)
    
    def _gerar_recomendacoes_inteligentes(self, disciplina: Dict, faixa_etaria: Dict, 
                                        tipo_atividade: Dict, contexto_tea: Dict, 
                                        tema: Dict) -> List[str]:
        """Gera recomendações inteligentes baseadas na análise"""
        recomendacoes = []
        
        # Recomendações por disciplina
        disc_principal = disciplina['principal']
        if disc_principal == 'matematica':
            recomendacoes.extend([
                "Incluir exercícios práticos com números concretos",
                "Usar exemplos do cotidiano da criança",
                "Adicionar elementos visuais para facilitar compreensão"
            ])
        elif disc_principal == 'ciencias':
            recomendacoes.extend([
                "Incluir experimentos simples e seguros",
                "Usar imagens e diagramas explicativos",
                "Conectar com a natureza e ambiente da criança"
            ])
        elif disc_principal == 'portugues':
            recomendacoes.extend([
                "Usar textos adequados à idade",
                "Incluir atividades de interpretação",
                "Variar tipos de exercícios (leitura, escrita, oral)"
            ])
        
        # Recomendações por faixa etária
        faixa = faixa_etaria['faixa']
        if faixa == 'infantil':
            recomendacoes.extend([
                "Usar linguagem muito simples e visual",
                "Incluir muitos elementos lúdicos e coloridos",
                "Manter atividades curtas (10-15 minutos)"
            ])
        elif faixa == 'fundamental1':
            recomendacoes.extend([
                "Equilibrar texto e imagens",
                "Incluir instruções claras passo a passo",
                "Adicionar elementos de gamificação"
            ])
        
        # Recomendações para TEA
        if contexto_tea['presente']:
            recomendacoes.extend([
                "Estruturar atividade de forma muito clara e previsível",
                "Incluir instruções visuais detalhadas",
                "Considerar aspectos sensoriais",
                "Permitir tempo extra para processamento",
                "Usar rotinas estabelecidas"
            ])
        
        # Recomendações por tipo de atividade
        tipo = tipo_atividade['tipo']
        if tipo == 'jogos':
            recomendacoes.extend([
                "Tornar interativo e divertido",
                "Incluir sistema de pontuação ou recompensas",
                "Adicionar elementos de competição saudável"
            ])
        elif tipo == 'experimentos':
            recomendacoes.extend([
                "Garantir segurança em todos os procedimentos",
                "Incluir lista detalhada de materiais",
                "Explicar o 'porquê' dos resultados"
            ])
        
        return list(set(recomendacoes))  # Remove duplicatas


class GeradorConteudoInteligentePlus:
    """
    Sistema avançado de geração de conteúdo educativo
    """
    
    def __init__(self):
        self.analisador = AnalisadorPedidosAvancado()
        self.templates_avancados = self._carregar_templates_avancados()
        self.historico_geracoes = []
    
    def gerar_conteudo_inteligente(self, pedido_usuario: str) -> Dict[str, Any]:
        """
        Gera conteúdo educativo inteligente baseado no pedido do usuário
        """
        # Análise avançada do pedido
        analise = self.analisador.analisar_pedido_avancado(pedido_usuario)
        
        # Seleciona template mais apropriado
        template = self._selecionar_template_inteligente(analise)
        
        # Gera conteúdo personalizado
        conteudo = self._gerar_conteudo_personalizado_avancado(analise, template)
        
        # Avalia qualidade do conteúdo gerado
        qualidade = self._avaliar_qualidade_conteudo(analise, conteudo)
        
        # Registra no histórico
        resultado = {
            'analise': analise,
            'conteudo_gerado': conteudo,
            'template_usado': template['nome'],
            'qualidade_estimada': qualidade,
            'timestamp': datetime.datetime.now().isoformat(),
            'id_geracao': self._gerar_id_unico()
        }
        
        self.historico_geracoes.append(resultado)
        
        return resultado
    
    def _carregar_templates_avancados(self) -> Dict[str, Any]:
        """Carrega templates avançados de conteúdo"""
        return {
            'matematica_exercicios_tea': {
                'nome': 'Exercícios de Matemática para TEA',
                'estrutura': [
                    'Título claro e objetivo',
                    'Instruções visuais passo a passo',
                    'Exercícios com progressão gradual',
                    'Elementos visuais de apoio',
                    'Sistema de recompensas',
                    'Gabarito com explicações visuais'
                ],
                'adaptacoes_tea': True
            },
            'ciencias_experimento_infantil': {
                'nome': 'Experimento de Ciências para Educação Infantil',
                'estrutura': [
                    'História introdutória',
                    'Materiais com imagens',
                    'Passo a passo ilustrado',
                    'Momento "UAU!" (descoberta)',
                    'Explicação simples',
                    'Atividade de extensão'
                ],
                'faixa_etaria': 'infantil'
            },
            'portugues_leitura_fundamental': {
                'nome': 'Atividade de Leitura - Fundamental',
                'estrutura': [
                    'Texto adequado à idade',
                    'Vocabulário destacado',
                    'Questões de compreensão',
                    'Atividades de vocabulário',
                    'Produção textual orientada',
                    'Autoavaliação'
                ]
            },
            'jogo_educativo_universal': {
                'nome': 'Jogo Educativo Universal',
                'estrutura': [
                    'Regras claras e simples',
                    'Materiais acessíveis',
                    'Múltiplos níveis de dificuldade',
                    'Sistema de pontuação',
                    'Variações do jogo',
                    'Conexão com aprendizado'
                ]
            },
            'arte_criativa_expressiva': {
                'nome': 'Atividade de Arte Criativa',
                'estrutura': [
                    'Inspiração e motivação',
                    'Materiais e técnicas',
                    'Processo criativo guiado',
                    'Momentos de reflexão',
                    'Compartilhamento e exposição',
                    'Conexões interdisciplinares'
                ]
            }
        }
    
    def _selecionar_template_inteligente(self, analise: Dict[str, Any]) -> Dict[str, Any]:
        """Seleção inteligente de template baseada na análise completa"""
        disciplina = analise['disciplina']['principal']
        tipo_atividade = analise['tipo_atividade']['tipo']
        faixa_etaria = analise['faixa_etaria']['faixa']
        contexto_tea = analise['contexto_tea']['presente']
        
        # Prioriza templates específicos para TEA
        if contexto_tea:
            chave_tea = f"{disciplina}_{tipo_atividade}_tea"
            if chave_tea in self.templates_avancados:
                return self.templates_avancados[chave_tea]
        
        # Prioriza templates por faixa etária
        chave_idade = f"{disciplina}_{tipo_atividade}_{faixa_etaria}"
        if chave_idade in self.templates_avancados:
            return self.templates_avancados[chave_idade]
        
        # Template por disciplina e tipo
        chave_basica = f"{disciplina}_{tipo_atividade}"
        if chave_basica in self.templates_avancados:
            return self.templates_avancados[chave_basica]
        
        # Template por tipo de atividade
        chave_tipo = f"{tipo_atividade}_educativo_universal"
        if chave_tipo in self.templates_avancados:
            return self.templates_avancados[chave_tipo]
        
        # Fallback para template universal
        return self.templates_avancados.get('jogo_educativo_universal', {
            'nome': 'Template Genérico',
            'estrutura': ['Introdução', 'Desenvolvimento', 'Atividades', 'Conclusão']
        })
    
    def _gerar_conteudo_personalizado_avancado(self, analise: Dict[str, Any], 
                                             template: Dict[str, Any]) -> str:
        """Geração avançada de conteúdo personalizado"""
        
        tema = analise['tema_principal']['tema']
        disciplina = analise['disciplina']['principal']
        faixa_etaria = analise['faixa_etaria']['faixa']
        contexto_tea = analise['contexto_tea']['presente']
        subtemas = analise['tema_principal']['subtemas']
        
        # Gera conteúdo baseado em padrões específicos
        if any(subtema in ['animais', 'plantas', 'natureza'] for subtema in subtemas):
            return self._gerar_conteudo_natureza(tema, faixa_etaria, contexto_tea)
        elif disciplina == 'matematica':
            return self._gerar_conteudo_matematica_avancado(tema, faixa_etaria, contexto_tea)
        elif disciplina == 'ciencias':
            return self._gerar_conteudo_ciencias_avancado(tema, faixa_etaria, contexto_tea)
        elif disciplina == 'portugues':
            return self._gerar_conteudo_portugues_avancado(tema, faixa_etaria, contexto_tea)
        else:
            return self._gerar_conteudo_generico_avancado(tema, disciplina, faixa_etaria, contexto_tea)
    
    def _gerar_conteudo_natureza(self, tema: str, faixa_etaria: str, contexto_tea: bool) -> str:
        """Gera conteúdo específico sobre natureza"""
        if contexto_tea:
            return f"""
# 🌿 Explorando a Natureza: {tema}

## 📋 Rotina da Atividade (Previsível e Estruturada)

### ⏰ Tempo Total: 30 minutos
1. **Preparação** (5 min) - Organizar materiais
2. **Exploração** (15 min) - Atividade principal
3. **Registro** (5 min) - Desenhar ou anotar
4. **Compartilhar** (5 min) - Mostrar descobertas

## 🎯 Objetivo Claro
Conhecer e observar elementos da natureza relacionados a {tema} de forma calma e organizada.

## 📦 Materiais Necessários (com imagens)
- 📝 Caderno de observação
- 🖍️ Lápis de cor
- 🔍 Lupa (opcional)
- 📷 Câmera ou celular
- 🧤 Luvas (se necessário)

## 👀 Instruções Visuais Passo a Passo

### Passo 1: Preparação Sensorial
- Respire fundo 3 vezes
- Observe o ambiente ao redor
- Identifique sons da natureza

### Passo 2: Observação Estruturada
- Olhe para {tema} por 2 minutos
- Conte quantos elementos você vê
- Observe as cores presentes
- Note as texturas (sem tocar ainda)

### Passo 3: Exploração Tátil (Opcional)
- Se confortável, toque gentilmente
- Descreva a sensação
- Compare com outras texturas conhecidas

### Passo 4: Registro Visual
- Desenhe o que observou
- Use as cores reais
- Adicione detalhes importantes

## 🏆 Sistema de Conquistas
- ⭐ Observador: Notou 3 detalhes diferentes
- 🎨 Artista: Fez um desenho completo
- 🔍 Detetive: Descobriu algo novo
- 📚 Cientista: Fez uma pergunta interessante

## 🔄 Rotina de Finalização
1. Guardar materiais no lugar
2. Lavar as mãos
3. Compartilhar uma descoberta
4. Planejar próxima exploração

## 💡 Adaptações Sensoriais
- **Som**: Use protetores auriculares se necessário
- **Toque**: Luvas disponíveis para sensibilidade tátil
- **Visual**: Óculos de sol para sensibilidade à luz
- **Movimento**: Pausas quando necessário
"""
        else:
            return f"""
# 🌿 Descobrindo a Natureza: {tema}

## 🎯 Objetivo
Explorar e aprender sobre {tema} através da observação direta e atividades práticas.

## 🌟 Atividades de Exploração

### 1. Caça ao Tesouro Natural 🔍
Encontre e observe:
- Diferentes tipos de {tema}
- Variações de cor e tamanho
- Elementos únicos ou especiais

### 2. Diário do Explorador 📖
- Desenhe suas descobertas
- Anote características interessantes
- Faça perguntas sobre o que viu

### 3. Comparação e Classificação 📊
- Compare diferentes exemplares
- Agrupe por características similares
- Crie categorias próprias

### 4. Investigação Científica 🔬
- Formule hipóteses sobre {tema}
- Teste suas ideias com observação
- Tire conclusões baseadas no que viu

## 🎨 Atividades Criativas
- Crie uma história sobre {tema}
- Faça um desenho científico detalhado
- Invente um jogo relacionado ao tema
- Compose uma música ou poema

## 🤔 Perguntas para Reflexão
1. O que mais te surpreendeu sobre {tema}?
2. Como {tema} se relaciona com outros elementos da natureza?
3. Que perguntas você ainda tem sobre {tema}?
4. Como podemos cuidar melhor de {tema}?

## 🏠 Extensão para Casa
- Continue observando {tema} em casa
- Pesquise mais informações sobre o tema
- Compartilhe descobertas com a família
- Crie um projeto sobre {tema}
"""
    
    def _gerar_conteudo_matematica_avancado(self, tema: str, faixa_etaria: str, contexto_tea: bool) -> str:
        """Gera conteúdo avançado de matemática"""
        if contexto_tea:
            return f"""
# 🔢 Matemática Estruturada: {tema}

## 📋 Rotina de Aprendizado (30 minutos)

### ⏰ Cronograma Visual
```
🟢 Início (5 min) → 🔵 Prática (15 min) → 🟡 Revisão (5 min) → 🟣 Celebração (5 min)
```

## 🎯 Objetivo Específico
Compreender e praticar conceitos de {tema} usando métodos visuais e estruturados.

## 📦 Kit de Materiais Organizados
- 📊 Blocos ou objetos para contar
- 📝 Folha de exercícios estruturada
- 🖍️ Lápis e borracha
- ⏰ Timer visual
- 🏆 Adesivos de recompensa

## 👀 Sequência de Aprendizado

### Etapa 1: Preparação Mental (5 min)
1. Sente-se confortavelmente
2. Respire fundo 3 vezes
3. Olhe para os materiais organizados
4. Diga: "Estou pronto para aprender {tema}"

### Etapa 2: Exploração Concreta (10 min)
- Use objetos físicos para representar {tema}
- Conte em voz alta
- Mova os objetos de forma organizada
- Observe padrões e relações

### Etapa 3: Representação Visual (10 min)
- Desenhe o que fez com os objetos
- Use símbolos matemáticos simples
- Conecte desenhos com números
- Verifique se está correto

### Etapa 4: Prática Estruturada (10 min)
- Complete exercícios passo a passo
- Use a mesma sequência para cada problema
- Marque cada resposta antes de continuar
- Peça ajuda se necessário

## 🏆 Sistema de Progresso
- ✅ Completou preparação
- ✅ Usou objetos corretamente
- ✅ Fez representação visual
- ✅ Resolveu problemas
- ⭐ PARABÉNS! Dominou {tema}

## 🔄 Rotina de Encerramento
1. Guardar materiais em ordem
2. Revisar o que aprendeu
3. Receber adesivo de conquista
4. Planejar próxima sessão

## 💡 Estratégias de Apoio
- **Pausas**: A cada 5 minutos se necessário
- **Repetição**: Mesmo método sempre
- **Visual**: Sempre mostrar antes de fazer
- **Celebração**: Reconhecer cada pequeno progresso
"""
        else:
            return f"""
# 🔢 Aventura Matemática: {tema}

## 🎯 Missão Matemática
Dominar os conceitos de {tema} através de desafios divertidos e práticos!

## 🚀 Aquecimento Matemático
- Conte de 1 a 10 (ou mais, dependendo da idade)
- Faça movimentos corporais com números
- Cante uma música com {tema}

## 🎮 Jogos e Atividades

### 🎯 Desafio 1: Detetive dos Números
- Encontre exemplos de {tema} ao seu redor
- Conte quantos você consegue identificar
- Registre suas descobertas

### 🧩 Desafio 2: Quebra-Cabeça Matemático
- Resolva problemas usando {tema}
- Use diferentes estratégias
- Explique seu raciocínio

### 🏃 Desafio 3: Corrida Matemática
- Resolva exercícios contra o tempo
- Cada acerto vale pontos
- Celebre suas conquistas

### 🎨 Desafio 4: Arte Matemática
- Crie desenhos usando {tema}
- Faça padrões e sequências
- Combine arte com matemática

## 📊 Problemas Práticos
1. **Situação Real**: [Problema do cotidiano com {tema}]
2. **Desafio Criativo**: [Problema que estimula criatividade]
3. **Investigação**: [Problema que requer pesquisa]

## 🏆 Níveis de Conquista
- 🥉 Bronze: Compreendeu o conceito básico
- 🥈 Prata: Resolveu problemas simples
- 🥇 Ouro: Criou seus próprios problemas
- 💎 Diamante: Ensinou para outra pessoa

## 🎉 Celebração do Aprendizado
- Compartilhe suas estratégias favoritas
- Crie um problema para desafiar colegas
- Explique {tema} para alguém da família
- Planeje como usar {tema} no dia a dia
"""
    
    def _gerar_conteudo_ciencias_avancado(self, tema: str, faixa_etaria: str, contexto_tea: bool) -> str:
        """Gera conteúdo avançado de ciências"""
        # Implementação similar aos outros métodos...
        return f"# 🔬 Conteúdo de Ciências sobre {tema} (em desenvolvimento)"
    
    def _gerar_conteudo_portugues_avancado(self, tema: str, faixa_etaria: str, contexto_tea: bool) -> str:
        """Gera conteúdo avançado de português"""
        # Implementação similar aos outros métodos...
        return f"# 📚 Conteúdo de Português sobre {tema} (em desenvolvimento)"
    
    def _gerar_conteudo_generico_avancado(self, tema: str, disciplina: str, faixa_etaria: str, contexto_tea: bool) -> str:
        """Gera conteúdo genérico avançado"""
        return f"""
# 🎓 Explorando: {tema}

## 🎯 Objetivo de Aprendizagem
Desenvolver conhecimentos e habilidades relacionadas a {tema} de forma envolvente e significativa.

## 🌟 Atividades Principais

### 1. Investigação Inicial 🔍
- O que você já sabe sobre {tema}?
- Que perguntas você tem sobre {tema}?
- Onde podemos encontrar {tema} no nosso dia a dia?

### 2. Exploração Prática 🛠️
- Atividade hands-on relacionada a {tema}
- Observação e experimentação
- Registro de descobertas

### 3. Conexões e Relações 🔗
- Como {tema} se conecta com outras áreas?
- Que exemplos reais podemos encontrar?
- Como isso afeta nossa vida?

### 4. Criação e Expressão 🎨
- Crie algo relacionado a {tema}
- Expresse seu aprendizado de forma criativa
- Compartilhe com outros

## 🤔 Reflexão e Avaliação
- O que foi mais interessante sobre {tema}?
- Que desafios você enfrentou?
- Como você pode aplicar isso no futuro?
- Que novas perguntas surgiram?

## 🏠 Extensão e Aplicação
- Continue explorando {tema} em casa
- Compartilhe com família e amigos
- Procure mais informações sobre o assunto
- Aplique o que aprendeu em situações reais
"""
    
    def _avaliar_qualidade_conteudo(self, analise: Dict[str, Any], conteudo: str) -> Dict[str, Any]:
        """Avalia a qualidade do conteúdo gerado"""
        score_qualidade = 0.0
        criterios = {}
        
        # Critério 1: Adequação à faixa etária
        faixa = analise['faixa_etaria']['faixa']
        if faixa == 'infantil' and any(palavra in conteudo.lower() for palavra in ['simples', 'visual', 'lúdico']):
            criterios['adequacao_idade'] = 0.9
        else:
            criterios['adequacao_idade'] = 0.7
        
        # Critério 2: Clareza das instruções
        if '##' in conteudo and 'passo' in conteudo.lower():
            criterios['clareza_instrucoes'] = 0.8
        else:
            criterios['clareza_instrucoes'] = 0.6
        
        # Critério 3: Elementos visuais
        if any(emoji in conteudo for emoji in ['🎯', '📋', '🎨', '🔍', '⭐']):
            criterios['elementos_visuais'] = 0.9
        else:
            criterios['elementos_visuais'] = 0.5
        
        # Critério 4: Adaptações para TEA
        if analise['contexto_tea']['presente']:
            if any(palavra in conteudo.lower() for palavra in ['rotina', 'estruturada', 'visual', 'passo a passo']):
                criterios['adaptacao_tea'] = 1.0
            else:
                criterios['adaptacao_tea'] = 0.3
        else:
            criterios['adaptacao_tea'] = 1.0  # N/A
        
        # Critério 5: Completude do conteúdo
        if len(conteudo) > 500 and '##' in conteudo:
            criterios['completude'] = 0.9
        else:
            criterios['completude'] = 0.6
        
        # Calcula score final
        score_qualidade = sum(criterios.values()) / len(criterios)
        
        return {
            'score_geral': score_qualidade,
            'criterios': criterios,
            'nivel': 'Excelente' if score_qualidade > 0.8 else 'Bom' if score_qualidade > 0.6 else 'Adequado'
        }
    
    def _gerar_id_unico(self) -> str:
        """Gera ID único para a geração"""
        import uuid
        return str(uuid.uuid4())[:8]
    
    def obter_historico(self) -> List[Dict[str, Any]]:
        """Retorna histórico de gerações"""
        return self.historico_geracoes
    
    def obter_estatisticas(self) -> Dict[str, Any]:
        """Retorna estatísticas do sistema"""
        if not self.historico_geracoes:
            return {'total_geracoes': 0}
        
        total = len(self.historico_geracoes)
        qualidades = [g['qualidade_estimada']['score_geral'] for g in self.historico_geracoes]
        
        return {
            'total_geracoes': total,
            'qualidade_media': sum(qualidades) / len(qualidades),
            'melhor_qualidade': max(qualidades),
            'disciplinas_mais_usadas': self._contar_disciplinas(),
            'tipos_atividade_mais_usados': self._contar_tipos_atividade()
        }
    
    def _contar_disciplinas(self) -> Dict[str, int]:
        """Conta disciplinas mais utilizadas"""
        contador = {}
        for geracao in self.historico_geracoes:
            disc = geracao['analise']['disciplina']['principal']
            contador[disc] = contador.get(disc, 0) + 1
        return contador
    
    def _contar_tipos_atividade(self) -> Dict[str, int]:
        """Conta tipos de atividade mais utilizados"""
        contador = {}
        for geracao in self.historico_geracoes:
            tipo = geracao['analise']['tipo_atividade']['tipo']
            contador[tipo] = contador.get(tipo, 0) + 1
        return contador


# Função principal para compatibilidade
def gerar_conteudo_inteligente(pedido_usuario: str) -> Dict[str, Any]:
    """
    Função principal para gerar conteúdo inteligente
    """
    gerador = GeradorConteudoInteligentePlus()
    return gerador.gerar_conteudo_inteligente(pedido_usuario)

