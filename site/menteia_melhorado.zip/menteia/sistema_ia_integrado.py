"""
Sistema Integrado de IA para Geração de Conteúdo Educativo
Combina geração inteligente de texto e imagem
"""

import os
import json
from typing import Dict, List, Any, Optional
from ia_inteligente import GeradorConteudoInteligentePlus
from media_generate_image import GeradorImagemInteligente

class SistemaIAIntegrado:
    """
    Sistema principal que integra geração de texto e imagem de forma inteligente
    """
    
    def __init__(self):
        self.gerador_texto = GeradorConteudoInteligentePlus()
        self.gerador_imagem = GeradorImagemInteligente()
        self.historico_completo = []
    
    def processar_pedido_completo(self, pedido_usuario: str, incluir_imagem: bool = True) -> Dict[str, Any]:
        """
        Processa um pedido completo gerando texto e imagem quando apropriado
        """
        try:
            # Gera conteúdo de texto
            resultado_texto = self.gerador_texto.gerar_conteudo_inteligente(pedido_usuario)
            
            resultado_final = {
                'sucesso': True,
                'conteudo_texto': resultado_texto,
                'conteudo_imagem': None,
                'recomendacoes_uso': [],
                'timestamp': resultado_texto['timestamp']
            }
            
            # Verifica se deve gerar imagem
            if incluir_imagem and self._deve_gerar_imagem(resultado_texto['analise']):
                resultado_imagem = self._gerar_imagem_contextual(resultado_texto['analise'])
                resultado_final['conteudo_imagem'] = resultado_imagem
            
            # Gera recomendações de uso
            resultado_final['recomendacoes_uso'] = self._gerar_recomendacoes_uso(resultado_texto['analise'])
            
            # Registra no histórico
            self.historico_completo.append(resultado_final)
            
            return resultado_final
            
        except Exception as e:
            return {
                'sucesso': False,
                'erro': str(e),
                'conteudo_texto': None,
                'conteudo_imagem': None
            }
    
    def _deve_gerar_imagem(self, analise: Dict[str, Any]) -> bool:
        """
        Determina se deve gerar imagem baseado na análise do pedido
        """
        # Sempre gera imagem para atividades de arte
        if analise['tipo_atividade']['tipo'] == 'arte':
            return True
        
        # Gera imagem para conteúdo visual (crianças pequenas)
        if analise['faixa_etaria']['faixa'] in ['infantil', 'fundamental1']:
            return True
        
        # Gera imagem para contexto TEA (apoio visual)
        if analise['contexto_tea']['presente']:
            return True
        
        # Gera imagem para temas específicos
        subtemas_visuais = ['animais', 'plantas', 'formas', 'cores', 'números']
        if any(subtema in analise['tema_principal']['subtemas'] for subtema in subtemas_visuais):
            return True
        
        # Gera imagem para disciplinas que se beneficiam de apoio visual
        disciplinas_visuais = ['ciencias', 'matematica', 'geografia']
        if analise['disciplina']['principal'] in disciplinas_visuais:
            return True
        
        return False
    
    def _gerar_imagem_contextual(self, analise: Dict[str, Any]) -> Dict[str, Any]:
        """
        Gera imagem baseada no contexto da análise
        """
        tema = analise['tema_principal']['tema']
        faixa_etaria = analise['faixa_etaria']['faixa']
        tipo_atividade = analise['tipo_atividade']['tipo']
        contexto_tea = analise['contexto_tea']['presente']
        
        # Define estilo baseado no contexto
        estilo = self._determinar_estilo_imagem(tipo_atividade, faixa_etaria, contexto_tea)
        
        # Mapeia faixa etária para formato de idade
        idade_formato = self._mapear_idade_formato(faixa_etaria)
        
        # Gera a imagem
        resultado = self.gerador_imagem.gerar_imagem_educativa(
            tema=tema,
            estilo=estilo,
            idade=idade_formato
        )
        
        return resultado
    
    def _determinar_estilo_imagem(self, tipo_atividade: str, faixa_etaria: str, contexto_tea: bool) -> str:
        """
        Determina o estilo de imagem mais apropriado
        """
        if contexto_tea:
            return 'simples'  # Sempre simples para TEA
        
        if tipo_atividade == 'arte':
            return 'simples'  # Para colorir
        
        if faixa_etaria == 'infantil':
            return 'simples'
        elif faixa_etaria == 'fundamental1':
            return 'educativo'
        elif faixa_etaria == 'fundamental2':
            return 'detalhado'
        else:
            return 'detalhado'
    
    def _mapear_idade_formato(self, faixa_etaria: str) -> str:
        """
        Mapeia faixa etária para formato esperado pelo gerador de imagem
        """
        mapeamento = {
            'infantil': '3-5 anos',
            'fundamental1': '6-8 anos',
            'fundamental2': '9-12 anos',
            'medio': 'todas as idades'
        }
        return mapeamento.get(faixa_etaria, '6-8 anos')
    
    def _gerar_recomendacoes_uso(self, analise: Dict[str, Any]) -> List[str]:
        """
        Gera recomendações específicas de uso do conteúdo
        """
        recomendacoes = []
        
        faixa = analise['faixa_etaria']['faixa']
        tipo = analise['tipo_atividade']['tipo']
        contexto_tea = analise['contexto_tea']['presente']
        
        # Recomendações por faixa etária
        if faixa == 'infantil':
            recomendacoes.extend([
                "Use linguagem simples e muitas imagens",
                "Mantenha atividades curtas (10-15 minutos)",
                "Inclua elementos lúdicos e interativos",
                "Permita pausas frequentes"
            ])
        elif faixa == 'fundamental1':
            recomendacoes.extend([
                "Equilibre explicação e prática",
                "Use exemplos concretos do cotidiano",
                "Inclua atividades em grupo",
                "Varie os tipos de exercícios"
            ])
        
        # Recomendações por tipo de atividade
        if tipo == 'jogos':
            recomendacoes.extend([
                "Estabeleça regras claras desde o início",
                "Mantenha ambiente competitivo mas saudável",
                "Celebre participação além de resultados",
                "Adapte dificuldade conforme necessário"
            ])
        elif tipo == 'experimentos':
            recomendacoes.extend([
                "Priorize sempre a segurança",
                "Prepare materiais com antecedência",
                "Explique o 'porquê' dos resultados",
                "Conecte com conhecimentos prévios"
            ])
        
        # Recomendações para TEA
        if contexto_tea:
            recomendacoes.extend([
                "Mantenha rotina previsível e estruturada",
                "Use apoios visuais abundantes",
                "Permita tempo extra para processamento",
                "Considere sensibilidades sensoriais",
                "Ofereça escolhas quando possível",
                "Celebre pequenos progressos"
            ])
        
        # Recomendações gerais
        recomendacoes.extend([
            "Adapte o conteúdo às necessidades específicas",
            "Monitore engajamento e compreensão",
            "Conecte com interesses da criança",
            "Documente progressos e dificuldades"
        ])
        
        return list(set(recomendacoes))  # Remove duplicatas
    
    def gerar_relatorio_uso(self, id_geracao: str = None) -> Dict[str, Any]:
        """
        Gera relatório de uso do conteúdo gerado
        """
        if id_geracao:
            # Relatório específico
            geracao = next((g for g in self.historico_completo 
                          if g.get('conteudo_texto', {}).get('id_geracao') == id_geracao), None)
            if not geracao:
                return {'erro': 'Geração não encontrada'}
            
            return self._criar_relatorio_individual(geracao)
        else:
            # Relatório geral
            return self._criar_relatorio_geral()
    
    def _criar_relatorio_individual(self, geracao: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria relatório individual de uma geração
        """
        analise = geracao['conteudo_texto']['analise']
        
        return {
            'id_geracao': geracao['conteudo_texto']['id_geracao'],
            'timestamp': geracao['timestamp'],
            'tema': analise['tema_principal']['tema'],
            'disciplina': analise['disciplina']['principal'],
            'faixa_etaria': analise['faixa_etaria']['faixa'],
            'tipo_atividade': analise['tipo_atividade']['tipo'],
            'contexto_tea': analise['contexto_tea']['presente'],
            'qualidade_texto': geracao['conteudo_texto']['qualidade_estimada'],
            'imagem_gerada': geracao['conteudo_imagem'] is not None,
            'recomendacoes_uso': geracao['recomendacoes_uso'],
            'score_confianca': analise['score_confianca']
        }
    
    def _criar_relatorio_geral(self) -> Dict[str, Any]:
        """
        Cria relatório geral do sistema
        """
        if not self.historico_completo:
            return {'total_geracoes': 0, 'dados': 'Nenhuma geração realizada ainda'}
        
        total = len(self.historico_completo)
        
        # Estatísticas de texto
        stats_texto = self.gerador_texto.obter_estatisticas()
        
        # Estatísticas de imagem
        total_imagens = sum(1 for g in self.historico_completo if g['conteudo_imagem'])
        
        # Análise de contexto TEA
        total_tea = sum(1 for g in self.historico_completo 
                       if g['conteudo_texto']['analise']['contexto_tea']['presente'])
        
        return {
            'resumo_geral': {
                'total_geracoes': total,
                'total_imagens_geradas': total_imagens,
                'total_contexto_tea': total_tea,
                'taxa_sucesso': sum(1 for g in self.historico_completo if g['sucesso']) / total
            },
            'estatisticas_texto': stats_texto,
            'distribuicao_faixa_etaria': self._contar_faixas_etarias(),
            'distribuicao_tipos_atividade': self._contar_tipos_atividade_completo(),
            'qualidade_media': self._calcular_qualidade_media()
        }
    
    def _contar_faixas_etarias(self) -> Dict[str, int]:
        """
        Conta distribuição de faixas etárias
        """
        contador = {}
        for geracao in self.historico_completo:
            if geracao['sucesso']:
                faixa = geracao['conteudo_texto']['analise']['faixa_etaria']['faixa']
                contador[faixa] = contador.get(faixa, 0) + 1
        return contador
    
    def _contar_tipos_atividade_completo(self) -> Dict[str, int]:
        """
        Conta distribuição de tipos de atividade
        """
        contador = {}
        for geracao in self.historico_completo:
            if geracao['sucesso']:
                tipo = geracao['conteudo_texto']['analise']['tipo_atividade']['tipo']
                contador[tipo] = contador.get(tipo, 0) + 1
        return contador
    
    def _calcular_qualidade_media(self) -> float:
        """
        Calcula qualidade média das gerações
        """
        qualidades = []
        for geracao in self.historico_completo:
            if geracao['sucesso']:
                qualidade = geracao['conteudo_texto']['qualidade_estimada']['score_geral']
                qualidades.append(qualidade)
        
        return sum(qualidades) / len(qualidades) if qualidades else 0.0
    
    def exportar_conteudo(self, id_geracao: str, formato: str = 'markdown') -> str:
        """
        Exporta conteúdo gerado em diferentes formatos
        """
        geracao = next((g for g in self.historico_completo 
                      if g.get('conteudo_texto', {}).get('id_geracao') == id_geracao), None)
        
        if not geracao:
            return "Geração não encontrada"
        
        if formato == 'markdown':
            return self._exportar_markdown(geracao)
        elif formato == 'html':
            return self._exportar_html(geracao)
        elif formato == 'json':
            return json.dumps(geracao, indent=2, ensure_ascii=False)
        else:
            return "Formato não suportado"
    
    def _exportar_markdown(self, geracao: Dict[str, Any]) -> str:
        """
        Exporta conteúdo em formato Markdown
        """
        conteudo = geracao['conteudo_texto']['conteudo_gerado']
        
        # Adiciona metadados
        metadata = f"""---
ID: {geracao['conteudo_texto']['id_geracao']}
Data: {geracao['timestamp']}
Tema: {geracao['conteudo_texto']['analise']['tema_principal']['tema']}
Disciplina: {geracao['conteudo_texto']['analise']['disciplina']['principal']}
Faixa Etária: {geracao['conteudo_texto']['analise']['faixa_etaria']['faixa']}
Qualidade: {geracao['conteudo_texto']['qualidade_estimada']['nivel']}
---

"""
        
        # Adiciona recomendações
        recomendacoes = "\n## 📋 Recomendações de Uso\n\n"
        for rec in geracao['recomendacoes_uso']:
            recomendacoes += f"- {rec}\n"
        
        return metadata + conteudo + recomendacoes
    
    def _exportar_html(self, geracao: Dict[str, Any]) -> str:
        """
        Exporta conteúdo em formato HTML
        """
        # Implementação básica - pode ser expandida
        markdown_content = self._exportar_markdown(geracao)
        
        html = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conteúdo Educativo - {geracao['conteudo_texto']['analise']['tema_principal']['tema']}</title>
    <style>
        body {{ font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
        h1, h2, h3 {{ color: #2c3e50; }}
        .metadata {{ background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
        .recommendations {{ background: #e8f5e8; padding: 15px; border-radius: 5px; margin-top: 20px; }}
    </style>
</head>
<body>
    <div class="metadata">
        <h3>Informações do Conteúdo</h3>
        <p><strong>ID:</strong> {geracao['conteudo_texto']['id_geracao']}</p>
        <p><strong>Data:</strong> {geracao['timestamp']}</p>
        <p><strong>Tema:</strong> {geracao['conteudo_texto']['analise']['tema_principal']['tema']}</p>
        <p><strong>Disciplina:</strong> {geracao['conteudo_texto']['analise']['disciplina']['principal']}</p>
        <p><strong>Faixa Etária:</strong> {geracao['conteudo_texto']['analise']['faixa_etaria']['faixa']}</p>
        <p><strong>Qualidade:</strong> {geracao['conteudo_texto']['qualidade_estimada']['nivel']}</p>
    </div>
    
    <div class="content">
        """ + geracao['conteudo_texto']['conteudo_gerado'].replace('\n', '<br>') + """
    </div>
    
    <div class="recommendations">
        <h3>📋 Recomendações de Uso</h3>
        <ul>
"""
        
        for rec in geracao['recomendacoes_uso']:
            html += "            <li>" + rec + "</li>\n"
        
        html += """        </ul>
    </div>
</body>
</html>"""
        
        return html


# Instância global do sistema
sistema_ia = SistemaIAIntegrado()

# Funções de conveniência para compatibilidade
def processar_pedido_educativo(pedido: str, incluir_imagem: bool = True) -> Dict[str, Any]:
    """
    Função principal para processar pedidos educativos
    """
    return sistema_ia.processar_pedido_completo(pedido, incluir_imagem)

def obter_relatorio_sistema() -> Dict[str, Any]:
    """
    Obtém relatório geral do sistema
    """
    return sistema_ia.gerar_relatorio_uso()

def exportar_conteudo_gerado(id_geracao: str, formato: str = 'markdown') -> str:
    """
    Exporta conteúdo gerado
    """
    return sistema_ia.exportar_conteudo(id_geracao, formato)

