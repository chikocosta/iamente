# Funções específicas para geradores especiais

def gerar_jogo_educativo(tema, tipo_jogo, idade, participantes):
    """
    Gera um jogo educativo específico baseado nos parâmetros
    """
    # Mapeia tipos de jogos para templates específicos
    templates_jogos = {
        'Quiz': """# 🎯 Quiz Educativo: {tema}

## 🎮 Nome do Jogo
Quiz Desafio - {tema}

## 🎯 Objetivo
Testar e reforçar conhecimentos sobre {tema} de forma divertida e competitiva.

## 👥 Participantes
{participantes} - Idade: {idade}

## 🎲 Materiais Necessários
- Cartões com perguntas
- Papel para pontuação
- Cronômetro
- Prêmios simbólicos (adesivos, certificados)

## 📋 Regras do Jogo

### Preparação
1. Prepare 20 perguntas sobre {tema}
2. Divida em níveis: fácil (5 pts), médio (10 pts), difícil (15 pts)
3. Organize os participantes

### Como Jogar
1. Cada jogador escolhe uma pergunta por vez
2. Tem 30 segundos para responder
3. Resposta correta = ganha os pontos
4. Resposta errada = passa a vez
5. Ganha quem fizer mais pontos

## 🏆 Variações
- **Modo Equipe**: Divida em grupos
- **Modo Relâmpago**: 10 segundos por pergunta
- **Modo Ajuda**: Pode pedir dica (perde metade dos pontos)

## 📚 Exemplos de Perguntas sobre {tema}
1. [Pergunta fácil relacionada ao tema]
2. [Pergunta média relacionada ao tema]
3. [Pergunta difícil relacionada ao tema]

## 🎓 Dicas para o Educador
- Adapte a dificuldade conforme o grupo
- Celebre todas as tentativas
- Use as perguntas erradas como oportunidade de ensino
- Mantenha o ambiente descontraído

## ⏱️ Tempo Estimado: 30-45 minutos""",

        'Caça ao Tesouro': """# 🗺️ Caça ao Tesouro: {tema}

## 🎮 Nome do Jogo
Aventura do Conhecimento - {tema}

## 🎯 Objetivo
Encontrar pistas e resolver desafios relacionados a {tema} para descobrir o tesouro.

## 👥 Participantes
{participantes} - Idade: {idade}

## 🎲 Materiais Necessários
- Pistas escritas em papel
- Mapa do local
- "Tesouro" (livro, certificado, doces)
- Envelope para cada pista
- Lápis e papel para anotações

## 📋 Regras do Jogo

### Preparação
1. Esconda 5-7 pistas pelo ambiente
2. Cada pista leva à próxima
3. A última pista leva ao tesouro
4. Todas as pistas devem relacionar-se com {tema}

### Como Jogar
1. Entregue a primeira pista
2. Resolvam o desafio para descobrir o local
3. Encontrem a próxima pista
4. Continuem até encontrar o tesouro
5. Celebrem a descoberta!

## 🧩 Exemplos de Pistas sobre {tema}
1. **Pista 1**: [Charada relacionada ao tema]
2. **Pista 2**: [Problema matemático sobre o tema]
3. **Pista 3**: [Desenho para decifrar]
4. **Pista Final**: [Desafio que leva ao tesouro]

## 🏆 Variações
- **Individual**: Cada um segue sua própria trilha
- **Equipes**: Grupos competem entre si
- **Cooperativo**: Todos trabalham juntos

## 🎓 Dicas para o Educador
- Teste o percurso antes do jogo
- Tenha pistas extras caso alguma se perca
- Adapte a dificuldade conforme a idade
- Fotografe os momentos especiais

## ⏱️ Tempo Estimado: 45-60 minutos""",

        'Jogo da Memória': """# 🧠 Jogo da Memória: {tema}

## 🎮 Nome do Jogo
Memória Mágica - {tema}

## 🎯 Objetivo
Exercitar a memória enquanto aprende conceitos importantes sobre {tema}.

## 👥 Participantes
{participantes} - Idade: {idade}

## 🎲 Materiais Necessários
- 20 cartas (10 pares) relacionadas a {tema}
- Mesa ou superfície plana
- Cronômetro (opcional)
- Papel para pontuação

## 📋 Regras do Jogo

### Preparação
1. Crie 10 pares de cartas sobre {tema}
2. Misture todas as cartas
3. Coloque viradas para baixo em fileiras
4. Decidam a ordem dos jogadores

### Como Jogar
1. Cada jogador vira duas cartas por vez
2. Se formarem um par, fica com as cartas
3. Se não formarem par, vira novamente
4. Próximo jogador tenta
5. Ganha quem conseguir mais pares

## 🃏 Exemplos de Pares sobre {tema}
1. [Conceito] ↔ [Definição]
2. [Imagem] ↔ [Nome]
3. [Pergunta] ↔ [Resposta]
4. [Causa] ↔ [Efeito]

## 🏆 Variações
- **Modo Cooperativo**: Todos jogam juntos contra o tempo
- **Modo Educativo**: Explique cada par encontrado
- **Modo Avançado**: Adicione mais cartas

## 🎓 Dicas para o Educador
- Comece com menos pares para crianças menores
- Discuta cada par encontrado
- Permita que vejam todas as cartas antes de começar
- Celebre a memória e o aprendizado

## ⏱️ Tempo Estimado: 20-30 minutos"""
    }
    
    template = templates_jogos.get(tipo_jogo, templates_jogos['Quiz'])
    return template.format(
        tema=tema,
        tipo_jogo=tipo_jogo,
        idade=idade,
        participantes=participantes
    )

def gerar_desenho_para_colorir(tema, idade, estilo):
    """
    Gera instruções para criar desenho para colorir
    """
    template = """# 🎨 Desenho para Colorir: {tema}

## 🎯 Objetivo
Desenvolver coordenação motora e criatividade através da arte relacionada a {tema}.

## 👥 Idade Recomendada
{idade}

## 🎨 Estilo do Desenho
{estilo}

## 🖍️ Materiais Necessários
- Papel sulfite ou cartolina
- Lápis para esboço
- Canetas ou marcadores pretos
- Lápis de cor, giz de cera ou canetinhas
- Borracha

## 📝 Instruções para Criar o Desenho

### Passo 1: Planejamento (10 min)
1. Pense nos elementos principais de {tema}
2. Faça um esboço simples a lápis
3. Defina as formas básicas

### Passo 2: Contorno (15 min)
1. Repasse o esboço com caneta preta
2. Faça linhas claras e definidas
3. Adicione detalhes importantes
4. Apague as linhas de lápis

### Passo 3: Preparação para Colorir (5 min)
1. Verifique se todas as áreas estão fechadas
2. Adicione elementos decorativos se necessário
3. Teste com uma cópia antes de distribuir

## 🎨 Elementos para Incluir no Desenho sobre {tema}
- [Elemento principal 1]
- [Elemento principal 2]
- [Elemento decorativo 1]
- [Elemento decorativo 2]
- [Fundo temático]

## 🌈 Sugestões de Cores
- **Cores principais**: [Sugestões baseadas no tema]
- **Cores complementares**: [Cores que harmonizam]
- **Efeitos especiais**: [Técnicas de colorir]

## 🏆 Variações
- **Versão Simples**: Menos detalhes para crianças menores
- **Versão Complexa**: Mais elementos para crianças maiores
- **Versão Educativa**: Inclua números ou letras para colorir

## 🎓 Dicas para o Educador
- Tenha cópias extras disponíveis
- Ofereça diferentes materiais de colorir
- Exponha os trabalhos finalizados
- Conecte a atividade com o aprendizado sobre {tema}

## ⏱️ Tempo Estimado: 30-45 minutos para colorir"""
    
    return template.format(tema=tema, idade=idade, estilo=estilo)

def gerar_conteudo_livre(tema, tipo_conteudo, publico_alvo):
    """
    Gera conteúdo educativo livre baseado nos parâmetros
    """
    templates_conteudo = {
        'História': """# 📚 História Educativa: {tema}

## 🎯 Objetivo
Ensinar sobre {tema} através de uma narrativa envolvente e educativa.

## 👥 Público-Alvo
{publico_alvo}

## 📖 A História

### Era uma vez...
[Início cativante relacionado ao tema]

### Desenvolvimento
[Desenvolvimento da história incorporando conceitos de {tema}]

### Clímax
[Momento de tensão ou descoberta relacionado ao tema]

### Resolução
[Final que reforça o aprendizado sobre {tema}]

## 🤔 Perguntas para Reflexão
1. O que você aprendeu sobre {tema} na história?
2. Qual foi sua parte favorita? Por quê?
3. Como você aplicaria isso na vida real?
4. Que outras aventuras os personagens poderiam viver?

## 🎭 Atividades Complementares
- Dramatização da história
- Desenho dos personagens
- Criação de um final alternativo
- Discussão em grupo sobre o tema

## ⏱️ Tempo de Leitura: 10-15 minutos""",

        'Experimento': """# 🔬 Experimento: {tema}

## 🎯 Objetivo
Explorar {tema} através de experimentação prática e observação científica.

## 👥 Público-Alvo
{publico_alvo}

## 🧪 Materiais Necessários
- [Lista de materiais específicos para o tema]
- Papel para anotações
- Lápis
- Cronômetro (se necessário)

## 📋 Procedimento

### Preparação (10 min)
1. Organize todos os materiais
2. Prepare o espaço de trabalho
3. Discuta as expectativas

### Execução (20 min)
1. [Passo 1 específico do experimento]
2. [Passo 2 específico do experimento]
3. [Passo 3 específico do experimento]
4. Observe e registre os resultados

### Análise (10 min)
1. Discuta o que aconteceu
2. Compare com as expectativas
3. Explique o porquê dos resultados

## 🔍 O que Observar
- [Aspecto 1 relacionado ao tema]
- [Aspecto 2 relacionado ao tema]
- [Mudanças que podem ocorrer]

## 📝 Registro de Resultados
- **Hipótese inicial**: 
- **Observações durante o experimento**:
- **Resultado final**:
- **Conclusões**:

## 🎓 Explicação Científica
[Explicação simples do que aconteceu relacionado ao tema]

## ⏱️ Tempo Total: 40 minutos""",

        'Projeto': """# 🛠️ Projeto: {tema}

## 🎯 Objetivo
Criar um projeto prático relacionado a {tema} que demonstre aprendizado e criatividade.

## 👥 Público-Alvo
{publico_alvo}

## 📋 Descrição do Projeto
[Descrição detalhada do que será criado relacionado ao tema]

## 🎨 Materiais Necessários
- [Lista específica de materiais]
- Ferramentas básicas (tesoura, cola, etc.)
- Materiais decorativos
- Papel para planejamento

## 📝 Etapas do Projeto

### Etapa 1: Planejamento (15 min)
1. Defina o objetivo específico
2. Faça um esboço do projeto
3. Liste todos os materiais necessários

### Etapa 2: Preparação (10 min)
1. Organize o espaço de trabalho
2. Separe todos os materiais
3. Revise o plano

### Etapa 3: Execução (30 min)
1. [Passo específico 1]
2. [Passo específico 2]
3. [Passo específico 3]
4. Finalize os detalhes

### Etapa 4: Apresentação (10 min)
1. Prepare uma apresentação do projeto
2. Explique como se relaciona com {tema}
3. Compartilhe com outros

## 🏆 Critérios de Avaliação
- Criatividade na execução
- Conexão clara com {tema}
- Qualidade do acabamento
- Capacidade de explicar o projeto

## 🎓 Extensões Possíveis
- Criar uma versão melhorada
- Ensinar outros a fazer
- Conectar com outros temas
- Documentar o processo

## ⏱️ Tempo Total: 65 minutos"""
    }
    
    template = templates_conteudo.get(tipo_conteudo, templates_conteudo['História'])
    return template.format(tema=tema, publico_alvo=publico_alvo)

def gerar_instrucoes_educativas(tema, tipo_instrucao, nivel_dificuldade):
    """
    Gera instruções educativas específicas
    """
    template = """# 📋 Instruções: {tema}

## 🎯 Objetivo
Fornecer orientações claras e práticas sobre {tema}.

## 📊 Nível de Dificuldade
{nivel_dificuldade}

## 📝 Tipo de Instrução
{tipo_instrucao}

## 🔧 Preparação Necessária

### Materiais
- [Lista específica de materiais para {tema}]
- Espaço adequado
- Tempo disponível

### Conhecimentos Prévios
- [Conceitos básicos necessários]
- [Habilidades requeridas]

## 📋 Instruções Passo a Passo

### Passo 1: Preparação
1. [Instrução específica de preparação]
2. [Verificação de segurança se necessário]
3. [Organização do ambiente]

### Passo 2: Execução Inicial
1. [Primeira ação específica]
2. [Segunda ação específica]
3. [Verificação de progresso]

### Passo 3: Desenvolvimento
1. [Ação de desenvolvimento]
2. [Monitoramento do processo]
3. [Ajustes necessários]

### Passo 4: Finalização
1. [Ações de conclusão]
2. [Verificação final]
3. [Limpeza e organização]

## ⚠️ Pontos de Atenção
- [Cuidado específico 1]
- [Cuidado específico 2]
- [Sinais de que algo pode estar errado]

## ✅ Como Saber se Deu Certo
- [Indicador de sucesso 1]
- [Indicador de sucesso 2]
- [Resultado esperado]

## 🔄 Próximos Passos
- [O que fazer após completar]
- [Como praticar mais]
- [Variações possíveis]

## 💡 Dicas Extras
- [Dica prática 1]
- [Dica prática 2]
- [Truque para facilitar]

## ⏱️ Tempo Estimado: [Tempo baseado na complexidade]"""
    
    return template.format(
        tema=tema,
        tipo_instrucao=tipo_instrucao,
        nivel_dificuldade=nivel_dificuldade
    )

